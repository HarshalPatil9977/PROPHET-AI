/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        base: {
          950: '#0a0c10',
          900: '#0f1218',
          850: '#131720',
          800: '#181d28',
          700: '#232a38',
          600: '#323b4d',
          500: '#4a5468',
        },
        ink: {
          100: '#e8ebf1',
          300: '#aab2c5',
          500: '#7c86a0',
        },
        signal: {
          bull: '#3fb98a',
          bullDim: '#1f5a44',
          bear: '#d9584f',
          bearDim: '#6e2a26',
          amber: '#d9a441',
          info: '#4a90d9',
        },
        accent: {
          DEFAULT: '#5b7fe0',
          dim: '#2c3a63',
        }
      },
      fontFamily: {
        mono: ['"IBM Plex Mono"', 'ui-monospace', 'SFMono-Regular', 'monospace'],
        sans: ['"Inter"', 'ui-sans-serif', 'system-ui'],
      },
      fontSize: {
        '2xs': '0.6875rem',
      },
    },
  },
  plugins: [],
}
