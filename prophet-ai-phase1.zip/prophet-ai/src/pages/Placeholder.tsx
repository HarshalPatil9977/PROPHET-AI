import { useLocation } from 'react-router-dom'

const LABELS: Record<string, string> = {
  '/research': 'Research', '/technical': 'Technical', '/fundamentals': 'Fundamentals',
  '/news': 'News', '/regime': 'Market Regime', '/strategies': 'Strategies',
  '/backtesting': 'Backtesting', '/paper-trading': 'Paper Trading', '/portfolio': 'Portfolio',
  '/ai-chat': 'AI Chat', '/reports': 'Reports', '/performance': 'Performance',
  '/alerts': 'Alerts', '/options': 'Options',
}

export default function Placeholder() {
  const { pathname } = useLocation()
  const label = LABELS[pathname] ?? pathname.replace('/', '')

  return (
    <div className="flex h-[70vh] flex-col items-center justify-center gap-3 border border-dashed border-base-700 text-center">
      <p className="text-2xs uppercase tracking-wide text-ink-500 mono">{pathname}</p>
      <h1 className="text-lg font-semibold text-ink-100">{label}</h1>
      <p className="max-w-sm text-sm text-ink-500">Module coming in Phase 2</p>
    </div>
  )
}
