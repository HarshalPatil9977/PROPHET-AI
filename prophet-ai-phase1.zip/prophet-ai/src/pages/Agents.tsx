import { useEffect, useMemo, useState } from 'react'
import { getAgents } from '@/services/agents'
import type { AgentDefinition, AgentCategory } from '@/types'
import { AGENT_CATEGORIES } from '@/data/mock/agentRegistry'
import StatusPill from '@/components/common/StatusPill'
import { TableSkeleton } from '@/components/common/LoadingSkeleton'

export default function Agents() {
  const [agents, setAgents] = useState<AgentDefinition[]>([])
  const [loading, setLoading] = useState(true)
  const [category, setCategory] = useState<AgentCategory | 'ALL'>('ALL')

  useEffect(() => { getAgents().then(a => { setAgents(a); setLoading(false) }) }, [])

  const filtered = useMemo(() => category === 'ALL' ? agents : agents.filter(a => a.category === category), [agents, category])

  const counts = useMemo(() => {
    const map: Record<string, number> = { ALL: agents.length }
    AGENT_CATEGORIES.forEach(c => { map[c] = agents.filter(a => a.category === c).length })
    return map
  }, [agents])

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-lg font-semibold text-ink-100">Agent Registry</h1>
        <p className="text-2xs text-ink-500">{agents.length} agents registered · SIMULATED AGENT OUTPUT — no live inference connected in Phase 1.</p>
      </div>

      <div className="flex flex-wrap gap-1.5">
        <button onClick={() => setCategory('ALL')} className={`border px-2.5 py-1 text-2xs ${category === 'ALL' ? 'border-accent text-accent' : 'border-base-600 text-ink-500'}`}>
          All ({counts.ALL})
        </button>
        {AGENT_CATEGORIES.map(c => (
          <button key={c} onClick={() => setCategory(c)} className={`border px-2.5 py-1 text-2xs ${category === c ? 'border-accent text-accent' : 'border-base-600 text-ink-500'}`}>
            {c} ({counts[c]})
          </button>
        ))}
      </div>

      {loading ? <TableSkeleton rows={10} /> : (
        <div className="overflow-x-auto border border-base-700">
          <table className="w-full text-left text-2xs">
            <thead className="border-b border-base-700 bg-base-900 text-ink-500">
              <tr>
                <th className="px-3 py-2 uppercase tracking-wide">Agent</th>
                <th className="px-3 py-2 uppercase tracking-wide">Category</th>
                <th className="px-3 py-2 uppercase tracking-wide">Status</th>
                <th className="px-3 py-2 uppercase tracking-wide">Weight</th>
                <th className="px-3 py-2 uppercase tracking-wide">Version</th>
                <th className="px-3 py-2 uppercase tracking-wide">Last Run</th>
                <th className="px-3 py-2 uppercase tracking-wide">Performance</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(a => (
                <tr key={a.id} className="border-b border-base-800 hover:bg-base-900">
                  <td className="px-3 py-2">
                    <p className="font-medium text-ink-100">{a.name}</p>
                    <p className="text-ink-500">{a.description}</p>
                  </td>
                  <td className="px-3 py-2">{a.category}</td>
                  <td className="px-3 py-2"><StatusPill label={a.status} tone={a.status === 'ACTIVE' ? 'bull' : 'neutral'} /></td>
                  <td className="px-3 py-2 mono">{a.weight.toFixed(2)}</td>
                  <td className="px-3 py-2 mono">{a.version}</td>
                  <td className="px-3 py-2 text-ink-500">a few minutes ago</td>
                  <td className="px-3 py-2 text-ink-500">Pending outcomes (Phase 5/6)</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
