import { useEffect, useState } from 'react'
import CandlestickChart from '@/components/charts/CandlestickChart'
import { Panel } from '@/components/common/DataState'
import StatusPill from '@/components/common/StatusPill'
import { marketDataService } from '@/services/marketData'
import { getSignalsForSymbol } from '@/services/signals'
import { INSTRUMENTS } from '@/data/mock/instruments'
import type { Candle, Quote, Timeframe } from '@/types'
import { useRealtime } from '@/context/RealtimeContext'

const TIMEFRAMES: Timeframe[] = ['1m', '5m', '15m', '30m', '1h', '4h', '1D', '1W']
const INDICATORS = ['EMA 20', 'EMA 50', 'EMA 200', 'RSI', 'MACD', 'VWAP']

export default function Markets() {
  const { tick } = useRealtime()
  const [search, setSearch] = useState('')
  const [symbol, setSymbol] = useState('NIFTY')
  const [timeframe, setTimeframe] = useState<Timeframe>('1D')
  const [candles, setCandles] = useState<Candle[]>([])
  const [quote, setQuote] = useState<Quote | null>(null)
  const [activeIndicators, setActiveIndicators] = useState<string[]>(['EMA 20', 'VWAP'])
  const [aiSnapshot, setAiSnapshot] = useState<{ opinion: string; score: number; confidence: number } | null>(null)

  const filteredInstruments = INSTRUMENTS.filter(i =>
    i.symbol.toLowerCase().includes(search.toLowerCase()) || i.name.toLowerCase().includes(search.toLowerCase())
  ).slice(0, 8)

  useEffect(() => {
    let active = true
    marketDataService.getHistoricalData(symbol, timeframe, 90).then(c => active && setCandles(c))
    marketDataService.getQuote(symbol).then(q => active && setQuote(q))
    getSignalsForSymbol(symbol).then(res => active && setAiSnapshot({
      opinion: res.consensus.overallOpinion, score: res.consensus.overallScore, confidence: res.consensus.agreementPercent,
    }))
    return () => { active = false }
  }, [symbol, timeframe, tick])

  const instrument = INSTRUMENTS.find(i => i.symbol === symbol)

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-3">
        <div className="relative">
          <input
            value={search} onChange={e => setSearch(e.target.value)} placeholder="Search symbol…"
            className="focus-ring w-56 border border-base-600 bg-base-850 px-3 py-1.5 text-sm text-ink-100"
          />
          {search && (
            <div className="absolute z-10 mt-1 w-56 border border-base-600 bg-base-850 shadow-lg">
              {filteredInstruments.map(i => (
                <button
                  key={i.symbol}
                  onClick={() => { setSymbol(i.symbol); setSearch('') }}
                  className="block w-full px-3 py-1.5 text-left text-sm text-ink-100 hover:bg-base-800"
                >
                  <span className="font-medium">{i.symbol}</span> <span className="text-ink-500">{i.name}</span>
                </button>
              ))}
            </div>
          )}
        </div>

        <div className="flex border border-base-600">
          {TIMEFRAMES.map(tf => (
            <button
              key={tf}
              onClick={() => setTimeframe(tf)}
              className={`px-2.5 py-1.5 text-2xs mono ${timeframe === tf ? 'bg-accent text-white' : 'text-ink-300 hover:bg-base-800'}`}
            >
              {tf}
            </button>
          ))}
        </div>

        <div className="flex flex-wrap gap-1.5">
          {INDICATORS.map(ind => (
            <button
              key={ind}
              onClick={() => setActiveIndicators(a => a.includes(ind) ? a.filter(x => x !== ind) : [...a, ind])}
              className={`border px-2 py-1 text-2xs ${activeIndicators.includes(ind) ? 'border-accent text-accent' : 'border-base-600 text-ink-500'}`}
            >
              {ind}
            </button>
          ))}
        </div>
      </div>

      <Panel
        title={`${symbol} — ${instrument?.name ?? ''}`}
        action={quote && (
          <span className={`mono text-sm ${quote.change >= 0 ? 'text-signal-bull' : 'text-signal-bear'}`}>
            {quote.ltp.toFixed(2)} ({quote.change >= 0 ? '+' : ''}{quote.changePercent.toFixed(2)}%)
          </span>
        )}
      >
        {candles.length > 0 ? <CandlestickChart candles={candles} /> : <p className="text-2xs text-ink-500">Loading chart…</p>}
      </Panel>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-4">
        <Panel title="Market Statistics">
          {quote && (
            <div className="space-y-1.5 text-2xs">
              <div className="flex justify-between"><span className="text-ink-500">Open</span><span className="mono">{quote.open.toFixed(2)}</span></div>
              <div className="flex justify-between"><span className="text-ink-500">High</span><span className="mono">{quote.high.toFixed(2)}</span></div>
              <div className="flex justify-between"><span className="text-ink-500">Low</span><span className="mono">{quote.low.toFixed(2)}</span></div>
              <div className="flex justify-between"><span className="text-ink-500">Prev Close</span><span className="mono">{quote.prevClose.toFixed(2)}</span></div>
              <div className="flex justify-between"><span className="text-ink-500">Volume</span><span className="mono">{quote.volume.toLocaleString()}</span></div>
            </div>
          )}
        </Panel>

        <Panel title="Technical Snapshot">
          <p className="text-2xs text-ink-500">Active: {activeIndicators.join(', ') || 'None'}</p>
          <p className="mt-2 text-sm text-ink-100">Trend structure: constructive within range</p>
        </Panel>

        <Panel title="AI Snapshot — SIMULATED">
          {aiSnapshot && (
            <div className="space-y-1.5">
              <StatusPill
                label={aiSnapshot.opinion}
                tone={aiSnapshot.opinion === 'BULLISH' ? 'bull' : aiSnapshot.opinion === 'BEARISH' ? 'bear' : 'neutral'}
              />
              <p className="text-2xs text-ink-500">Score {aiSnapshot.score} · Agreement {aiSnapshot.confidence}%</p>
            </div>
          )}
        </Panel>

        <Panel title="Options / News Snapshot">
          <p className="text-2xs text-ink-500">Module coming in Phase 2</p>
        </Panel>
      </div>
    </div>
  )
}
