import { useState } from 'react'
import { useNavigate, Navigate } from 'react-router-dom'
import { useAuth } from '@/context/AuthContext'
import { DEMO_CREDENTIALS } from '@/services/auth'

export default function Login() {
  const { user, login } = useAuth()
  const navigate = useNavigate()
  const [email, setEmail] = useState('demo@prophet.ai')
  const [password, setPassword] = useState('demo1234')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  if (user) return <Navigate to="/dashboard" replace />

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError('')
    setLoading(true)
    try {
      await login(email, password)
      navigate('/dashboard')
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Login failed.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="flex h-screen w-screen items-center justify-center bg-base-950">
      <div className="w-full max-w-sm border border-base-700 bg-base-900 p-6">
        <div className="mb-6 text-center">
          <p className="text-xl font-bold tracking-tight text-ink-100">PROPHET AI</p>
          <p className="mt-1 text-2xs uppercase tracking-wide text-ink-500">Multi-Agent Market Intelligence</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3">
          <div>
            <label className="mb-1 block text-2xs uppercase tracking-wide text-ink-500">Email</label>
            <input
              type="email" value={email} onChange={e => setEmail(e.target.value)} required
              className="focus-ring w-full border border-base-600 bg-base-850 px-3 py-2 text-sm text-ink-100"
            />
          </div>
          <div>
            <label className="mb-1 block text-2xs uppercase tracking-wide text-ink-500">Password</label>
            <input
              type="password" value={password} onChange={e => setPassword(e.target.value)} required
              className="focus-ring w-full border border-base-600 bg-base-850 px-3 py-2 text-sm text-ink-100"
            />
          </div>
          {error && <p className="text-2xs text-signal-bear">{error}</p>}
          <button
            type="submit" disabled={loading}
            className="focus-ring w-full bg-accent px-3 py-2 text-sm font-medium text-white hover:bg-accent/90 disabled:opacity-50"
          >
            {loading ? 'Signing in…' : 'Sign in'}
          </button>
        </form>

        <div className="mt-5 border-t border-base-700 pt-4">
          <p className="mb-2 text-2xs uppercase tracking-wide text-ink-500">Demo credentials</p>
          <ul className="space-y-1 text-2xs mono text-ink-300">
            {DEMO_CREDENTIALS.map(c => (
              <li key={c.email} className="flex justify-between">
                <span>{c.email}</span><span className="text-ink-500">{c.password}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  )
}
