import { useEffect, useState } from 'react'
import IndexCard from '@/components/market/IndexCard'
import { Panel } from '@/components/common/DataState'
import StatusPill from '@/components/common/StatusPill'
import { TableSkeleton } from '@/components/common/LoadingSkeleton'
import { marketDataService } from '@/services/marketData'
import { getSignals } from '@/services/signals'
import { getScannerRows } from '@/services/scanner'
import { useRealtime } from '@/context/RealtimeContext'
import type { Signal, SectorPerformance } from '@/types'
import type { ScannerRow } from '@/services/scanner'
import { Link } from 'react-router-dom'

const INDICES = [
  { symbol: 'NIFTY', label: 'NIFTY 50' },
  { symbol: 'BANKNIFTY', label: 'BANK NIFTY' },
  { symbol: 'SENSEX', label: 'SENSEX' },
  { symbol: 'FINNIFTY', label: 'FINNIFTY' },
  { symbol: 'INDIAVIX', label: 'INDIA VIX' },
]

export default function Dashboard() {
  const { tick } = useRealtime()
  const [signals, setSignals] = useState<Signal[]>([])
  const [sectors, setSectors] = useState<SectorPerformance[]>([])
  const [movers, setMovers] = useState<ScannerRow[]>([])
  const [breadth, setBreadth] = useState<{ advancers: number; decliners: number; unchanged: number } | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let active = true
    Promise.all([getSignals(), marketDataService.getSectorPerformance(), getScannerRows(), marketDataService.getMarketBreadth()])
      .then(([sig, sec, rows, br]) => {
        if (!active) return
        setSignals(sig.slice(0, 5))
        setSectors(sec)
        setMovers([...rows].sort((a, b) => Math.abs(b.change) - Math.abs(a.change)).slice(0, 6))
        setBreadth(br)
        setLoading(false)
      })
    return () => { active = false }
  }, [tick])

  const avgScore = signals.length ? Math.round(signals.reduce((s, sig) => s + (sig.direction === 'BULLISH' ? sig.signalScore : -sig.signalScore), 0) / signals.length) : 0
  const overallOpinion = avgScore > 10 ? 'BULLISH' : avgScore < -10 ? 'BEARISH' : 'NEUTRAL'
  const agentCount = 58 // 60 registered minus 2 Master-tier

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
        {INDICES.map(idx => <IndexCard key={idx.symbol} symbol={idx.symbol} label={idx.label} />)}
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Panel title="AI Market Pulse — SIMULATED AI CONSENSUS">
          <div className="flex items-center justify-between">
            <StatusPill
              label={overallOpinion}
              tone={overallOpinion === 'BULLISH' ? 'bull' : overallOpinion === 'BEARISH' ? 'bear' : 'neutral'}
            />
            <span className="text-2xl font-bold mono text-ink-100">{avgScore > 0 ? '+' : ''}{avgScore}</span>
          </div>
          <div className="mt-3 grid grid-cols-3 gap-2 text-center text-2xs">
            <div>
              <p className="text-ink-500">Agents</p>
              <p className="mono text-ink-100">{agentCount}</p>
            </div>
            <div>
              <p className="text-ink-500">Agreement</p>
              <p className="mono text-ink-100">{signals[0]?.modelConfidence ?? '—'}%</p>
            </div>
            <div>
              <p className="text-ink-500">Risk Level</p>
              <p className="mono text-ink-100">{agentCount > 0 ? 'MODERATE' : '—'}</p>
            </div>
          </div>
        </Panel>

        <Panel title="Market Regime">
          <p className="text-sm text-ink-100">Trending — Moderate Volatility</p>
          <p className="mt-1 text-2xs text-ink-500">Classification derived from simulated breadth and volatility inputs. Full regime engine ships in Phase 2.</p>
        </Panel>

        <Panel title="Market Breadth">
          {breadth ? (
            <div className="space-y-1.5 text-sm">
              <div className="flex justify-between"><span className="text-signal-bull">Advancers</span><span className="mono">{breadth.advancers}</span></div>
              <div className="flex justify-between"><span className="text-signal-bear">Decliners</span><span className="mono">{breadth.decliners}</span></div>
              <div className="flex justify-between"><span className="text-ink-500">Unchanged</span><span className="mono">{breadth.unchanged}</span></div>
            </div>
          ) : <TableSkeleton rows={3} />}
        </Panel>
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <Panel title="Top Signals" action={<Link to="/signals" className="text-2xs text-accent hover:underline">View all →</Link>}>
          {loading ? <TableSkeleton /> : (
            <div className="space-y-2">
              {signals.map(s => (
                <div key={s.id} className="flex items-center justify-between border-b border-base-800 pb-2 last:border-0 last:pb-0">
                  <div className="flex items-center gap-2">
                    <StatusPill label={s.direction} tone={s.direction === 'BULLISH' ? 'bull' : 'bear'} />
                    <span className="text-sm font-medium text-ink-100">{s.symbol}</span>
                  </div>
                  <div className="text-right text-2xs">
                    <p className="mono text-ink-100">Score {s.signalScore}</p>
                    <p className="text-ink-500">{s.status.replace('_', ' ')}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Panel>

        <Panel title="Sector Heatmap">
          {loading ? <TableSkeleton /> : (
            <div className="grid grid-cols-2 gap-1.5 sm:grid-cols-3">
              {sectors.map(s => (
                <div
                  key={s.sector}
                  className="flex flex-col justify-between border p-2 text-2xs"
                  style={{
                    borderColor: s.changePercent >= 0 ? 'rgba(63,185,138,0.35)' : 'rgba(217,88,79,0.35)',
                    backgroundColor: s.changePercent >= 0 ? 'rgba(63,185,138,0.08)' : 'rgba(217,88,79,0.08)',
                  }}
                >
                  <span className="text-ink-300">{s.sector}</span>
                  <span className={`mono font-medium ${s.changePercent >= 0 ? 'text-signal-bull' : 'text-signal-bear'}`}>
                    {s.changePercent >= 0 ? '+' : ''}{s.changePercent.toFixed(2)}%
                  </span>
                </div>
              ))}
            </div>
          )}
        </Panel>
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <Panel title="Top Movers">
          {loading ? <TableSkeleton /> : (
            <div className="space-y-2">
              {movers.map(m => (
                <div key={m.symbol} className="flex items-center justify-between text-sm">
                  <span className="text-ink-100">{m.symbol}</span>
                  <span className={`mono ${m.change >= 0 ? 'text-signal-bull' : 'text-signal-bear'}`}>
                    {m.change >= 0 ? '+' : ''}{m.change.toFixed(2)}%
                  </span>
                </div>
              ))}
            </div>
          )}
        </Panel>

        <Panel title="AI Research Feed / Agent Activity" action={<Link to="/agents" className="text-2xs text-accent hover:underline">View agents →</Link>}>
          <div className="space-y-2 text-2xs">
            {signals.slice(0, 4).map(s => (
              <div key={s.id} className="border-b border-base-800 pb-2 last:border-0">
                <p className="text-ink-100">{s.symbol} — {s.evidence[0] ?? 'Evidence pending'}</p>
                <p className="mt-0.5 text-ink-500">{new Date(s.generatedAt).toLocaleTimeString()} · simulated output</p>
              </div>
            ))}
          </div>
        </Panel>
      </div>
    </div>
  )
}
