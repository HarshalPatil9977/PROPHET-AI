import { useEffect, useMemo, useState } from 'react'
import { getScannerRows, type ScannerRow } from '@/services/scanner'
import StatusPill from '@/components/common/StatusPill'
import { TableSkeleton } from '@/components/common/LoadingSkeleton'
import { useRealtime } from '@/context/RealtimeContext'

type SortKey = keyof ScannerRow
type SortDir = 'asc' | 'desc'

export default function Scanner() {
  const { tick } = useRealtime()
  const [rows, setRows] = useState<ScannerRow[]>([])
  const [loading, setLoading] = useState(true)
  const [sortKey, setSortKey] = useState<SortKey>('aiScore')
  const [sortDir, setSortDir] = useState<SortDir>('desc')
  const [minRsi, setMinRsi] = useState(0)
  const [maxRsi, setMaxRsi] = useState(100)
  const [trendFilter, setTrendFilter] = useState<'ALL' | ScannerRow['trend']>('ALL')

  useEffect(() => {
    let active = true
    setLoading(true)
    getScannerRows().then(r => { if (active) { setRows(r); setLoading(false) } })
    return () => { active = false }
  }, [tick])

  const filtered = useMemo(() => {
    const result = rows.filter(r => r.rsiApprox >= minRsi && r.rsiApprox <= maxRsi && (trendFilter === 'ALL' || r.trend === trendFilter))
    result.sort((a, b) => {
      const av = a[sortKey], bv = b[sortKey]
      if (typeof av === 'number' && typeof bv === 'number') return sortDir === 'asc' ? av - bv : bv - av
      return sortDir === 'asc' ? String(av).localeCompare(String(bv)) : String(bv).localeCompare(String(av))
    })
    return result
  }, [rows, sortKey, sortDir, minRsi, maxRsi, trendFilter])

  function toggleSort(key: SortKey) {
    if (sortKey === key) setSortDir(d => d === 'asc' ? 'desc' : 'asc')
    else { setSortKey(key); setSortDir('desc') }
  }

  const columns: { key: SortKey; label: string }[] = [
    { key: 'symbol', label: 'Symbol' }, { key: 'price', label: 'Price' }, { key: 'change', label: 'Change' },
    { key: 'volume', label: 'Volume' }, { key: 'rsiApprox', label: 'RSI' }, { key: 'vwapApprox', label: 'VWAP' },
    { key: 'trend', label: 'Trend' }, { key: 'aiScore', label: 'AI Score' }, { key: 'confidence', label: 'Confidence' },
    { key: 'signal', label: 'Signal' }, { key: 'risk', label: 'Risk' },
  ]

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-lg font-semibold text-ink-100">Market Scanner</h1>
        <p className="text-2xs text-ink-500">Client-side filtering over demo data — server-side filtering lands with a real data feed.</p>
      </div>

      <div className="flex flex-wrap items-center gap-3 border border-base-700 bg-base-900 p-3">
        <label className="flex items-center gap-2 text-2xs text-ink-500">
          RSI
          <input type="number" value={minRsi} onChange={e => setMinRsi(Number(e.target.value))} className="w-14 border border-base-600 bg-base-850 px-1.5 py-1 text-ink-100" />
          –
          <input type="number" value={maxRsi} onChange={e => setMaxRsi(Number(e.target.value))} className="w-14 border border-base-600 bg-base-850 px-1.5 py-1 text-ink-100" />
        </label>
        <label className="flex items-center gap-2 text-2xs text-ink-500">
          Trend
          <select value={trendFilter} onChange={e => setTrendFilter(e.target.value as any)} className="border border-base-600 bg-base-850 px-1.5 py-1 text-ink-100">
            <option value="ALL">All</option>
            <option value="UP">Up</option>
            <option value="DOWN">Down</option>
            <option value="SIDEWAYS">Sideways</option>
          </select>
        </label>
      </div>

      {loading ? <TableSkeleton rows={10} /> : (
        <div className="overflow-x-auto border border-base-700">
          <table className="w-full text-left text-2xs">
            <thead className="border-b border-base-700 bg-base-900 text-ink-500">
              <tr>
                {columns.map(c => (
                  <th key={c.key} onClick={() => toggleSort(c.key)} className="cursor-pointer select-none whitespace-nowrap px-3 py-2 font-medium uppercase tracking-wide hover:text-ink-100">
                    {c.label}{sortKey === c.key ? (sortDir === 'asc' ? ' ↑' : ' ↓') : ''}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map(r => (
                <tr key={r.symbol} className="border-b border-base-800 hover:bg-base-900">
                  <td className="px-3 py-2 font-medium text-ink-100">{r.symbol}</td>
                  <td className="px-3 py-2 mono">{r.price.toFixed(2)}</td>
                  <td className={`px-3 py-2 mono ${r.change >= 0 ? 'text-signal-bull' : 'text-signal-bear'}`}>{r.change >= 0 ? '+' : ''}{r.change.toFixed(2)}%</td>
                  <td className="px-3 py-2 mono">{r.volume.toLocaleString()}</td>
                  <td className="px-3 py-2 mono">{r.rsiApprox}</td>
                  <td className="px-3 py-2 mono">{r.vwapApprox.toFixed(2)}</td>
                  <td className="px-3 py-2">{r.trend}</td>
                  <td className="px-3 py-2 mono">{r.aiScore}</td>
                  <td className="px-3 py-2 mono">{r.confidence}%</td>
                  <td className="px-3 py-2"><StatusPill label={r.signal} tone={r.signal === 'BULLISH' ? 'bull' : r.signal === 'BEARISH' ? 'bear' : 'neutral'} /></td>
                  <td className="px-3 py-2"><StatusPill label={r.risk} tone={r.risk === 'LOW' ? 'bull' : r.risk === 'ELEVATED' ? 'bear' : 'amber'} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
