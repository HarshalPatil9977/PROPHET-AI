import { useEffect, useState } from 'react'
import type { Watchlist, Quote } from '@/types'
import * as watchlistService from '@/services/watchlists'
import { marketDataService } from '@/services/marketData'
import { generateAllAgentOutputs } from '@/ai/agents/DemoAgentProvider'
import { computeConsensus } from '@/ai/scoring/consensus'
import { generateCandles } from '@/data/mock/priceEngine'
import { INSTRUMENTS } from '@/data/mock/instruments'
import StatusPill from '@/components/common/StatusPill'
import { useRealtime } from '@/context/RealtimeContext'

export default function Watchlists() {
  const { tick } = useRealtime()
  const [lists, setLists] = useState<Watchlist[]>([])
  const [activeId, setActiveId] = useState<string>('')
  const [quotes, setQuotes] = useState<Record<string, Quote>>({})
  const [newListName, setNewListName] = useState('')
  const [newSymbol, setNewSymbol] = useState('')
  const [editingId, setEditingId] = useState<string | null>(null)
  const [renameValue, setRenameValue] = useState('')

  async function refresh() {
    const all = await watchlistService.getWatchlists()
    setLists(all)
    if (!activeId && all.length) setActiveId(all[0].id)
  }

  useEffect(() => { refresh() }, [])

  const active = lists.find(l => l.id === activeId)

  useEffect(() => {
    if (!active) return
    let cancelled = false
    Promise.all(active.items.map(i => marketDataService.getQuote(i.symbol))).then(qs => {
      if (cancelled) return
      const map: Record<string, Quote> = {}
      qs.forEach(q => { map[q.symbol] = q })
      setQuotes(map)
    })
    return () => { cancelled = true }
  }, [active, tick])

  function trendOf(symbol: string) {
    const outputs = generateAllAgentOutputs(symbol)
    return computeConsensus(symbol, outputs)
  }

  async function handleCreate() {
    if (!newListName.trim()) return
    const list = await watchlistService.createWatchlist(newListName.trim())
    setNewListName('')
    await refresh()
    setActiveId(list.id)
  }

  async function handleAddSymbol() {
    if (!active || !newSymbol.trim()) return
    await watchlistService.addSymbol(active.id, newSymbol.trim().toUpperCase())
    setNewSymbol('')
    refresh()
  }

  return (
    <div className="grid grid-cols-1 gap-4 lg:grid-cols-4">
      <div className="border border-base-700 bg-base-900 p-3 lg:col-span-1">
        <p className="mb-2 text-2xs uppercase tracking-wide text-ink-500">Watchlists</p>
        <div className="space-y-1">
          {lists.map(l => (
            <div key={l.id} className={`flex items-center justify-between px-2 py-1.5 text-sm ${activeId === l.id ? 'bg-accent/10 text-ink-100' : 'text-ink-300 hover:bg-base-800'}`}>
              {editingId === l.id ? (
                <input
                  autoFocus value={renameValue} onChange={e => setRenameValue(e.target.value)}
                  onBlur={async () => { await watchlistService.renameWatchlist(l.id, renameValue || l.name); setEditingId(null); refresh() }}
                  onKeyDown={async e => { if (e.key === 'Enter') (e.target as HTMLInputElement).blur() }}
                  className="w-full border border-base-600 bg-base-850 px-1 py-0.5 text-ink-100"
                />
              ) : (
                <button onClick={() => setActiveId(l.id)} className="flex-1 text-left">{l.name}</button>
              )}
              <div className="flex gap-1.5 text-2xs text-ink-500">
                <button onClick={() => { setEditingId(l.id); setRenameValue(l.name) }} className="hover:text-ink-100">rename</button>
                <button onClick={async () => { await watchlistService.deleteWatchlist(l.id); refresh() }} className="hover:text-signal-bear">delete</button>
              </div>
            </div>
          ))}
        </div>
        <div className="mt-3 flex gap-1.5">
          <input
            value={newListName} onChange={e => setNewListName(e.target.value)} placeholder="New watchlist"
            className="focus-ring w-full border border-base-600 bg-base-850 px-2 py-1 text-2xs text-ink-100"
          />
          <button onClick={handleCreate} className="focus-ring border border-base-600 px-2 text-2xs text-ink-100 hover:bg-base-800">Add</button>
        </div>
      </div>

      <div className="border border-base-700 bg-base-900 p-3 lg:col-span-3">
        {active ? (
          <>
            <div className="mb-3 flex items-center justify-between">
              <p className="text-sm font-medium text-ink-100">{active.name}</p>
              <div className="flex gap-1.5">
                <input
                  value={newSymbol} onChange={e => setNewSymbol(e.target.value)} placeholder="Add symbol (e.g. TCS)"
                  list="instrument-list"
                  className="focus-ring border border-base-600 bg-base-850 px-2 py-1 text-2xs text-ink-100"
                />
                <datalist id="instrument-list">
                  {INSTRUMENTS.map(i => <option key={i.symbol} value={i.symbol} />)}
                </datalist>
                <button onClick={handleAddSymbol} className="focus-ring border border-base-600 px-2 text-2xs text-ink-100 hover:bg-base-800">Add</button>
              </div>
            </div>

            <table className="w-full text-left text-2xs">
              <thead className="border-b border-base-700 text-ink-500">
                <tr>
                  <th className="py-1.5">Symbol</th><th>Price</th><th>Change</th><th>Volume</th><th>Trend</th><th>AI Score</th><th>Signal</th><th></th>
                </tr>
              </thead>
              <tbody>
                {active.items.map(item => {
                  const q = quotes[item.symbol]
                  const candles = generateCandles(item.symbol, '1D', 5)
                  const trendUp = candles[candles.length - 1].close > candles[0].close
                  const consensus = trendOf(item.symbol)
                  return (
                    <tr key={item.id} className="border-b border-base-800">
                      <td className="py-2 font-medium text-ink-100">{item.symbol}</td>
                      <td className="mono">{q?.ltp.toFixed(2) ?? '—'}</td>
                      <td className={`mono ${q && q.change >= 0 ? 'text-signal-bull' : 'text-signal-bear'}`}>{q ? `${q.change >= 0 ? '+' : ''}${q.changePercent.toFixed(2)}%` : '—'}</td>
                      <td className="mono">{q?.volume.toLocaleString() ?? '—'}</td>
                      <td>{trendUp ? 'UP' : 'DOWN'}</td>
                      <td className="mono">{consensus.overallScore}</td>
                      <td><StatusPill label={consensus.overallOpinion} tone={consensus.overallOpinion === 'BULLISH' ? 'bull' : consensus.overallOpinion === 'BEARISH' ? 'bear' : 'neutral'} /></td>
                      <td>
                        <button onClick={async () => { await watchlistService.removeSymbol(active.id, item.symbol); refresh() }} className="text-ink-500 hover:text-signal-bear">remove</button>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </>
        ) : <p className="text-2xs text-ink-500">Create a watchlist to get started.</p>}
      </div>
    </div>
  )
}
