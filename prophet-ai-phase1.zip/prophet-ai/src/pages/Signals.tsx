import { useEffect, useMemo, useState } from 'react'
import { getSignals } from '@/services/signals'
import type { Signal } from '@/types'
import StatusPill from '@/components/common/StatusPill'
import { TableSkeleton } from '@/components/common/LoadingSkeleton'
import { EmptyState } from '@/components/common/DataState'
import { useRealtime } from '@/context/RealtimeContext'

type Filter = 'ALL' | 'BULLISH' | 'BEARISH' | 'HIGH_CONFIDENCE' | 'INTRADAY' | 'SWING'

export default function Signals() {
  const { tick } = useRealtime()
  const [signals, setSignals] = useState<Signal[]>([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState<Filter>('ALL')
  const [expanded, setExpanded] = useState<string | null>(null)

  useEffect(() => {
    let active = true
    setLoading(true)
    getSignals().then(s => { if (active) { setSignals(s); setLoading(false) } })
    return () => { active = false }
  }, [tick])

  const filtered = useMemo(() => signals.filter(s => {
    switch (filter) {
      case 'BULLISH': return s.direction === 'BULLISH'
      case 'BEARISH': return s.direction === 'BEARISH'
      case 'HIGH_CONFIDENCE': return s.modelConfidence >= 70
      case 'INTRADAY': return s.timeframe === 'Intraday'
      case 'SWING': return s.timeframe.startsWith('Swing')
      default: return true
    }
  }), [signals, filter])

  const filters: { key: Filter; label: string }[] = [
    { key: 'ALL', label: 'All' }, { key: 'BULLISH', label: 'Bullish' }, { key: 'BEARISH', label: 'Bearish' },
    { key: 'HIGH_CONFIDENCE', label: 'High confidence' }, { key: 'INTRADAY', label: 'Intraday' }, { key: 'SWING', label: 'Swing' },
  ]

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-lg font-semibold text-ink-100">Signal Center</h1>
          <p className="text-2xs text-ink-500">Demo signals generated from simulated agent consensus — not investment advice.</p>
        </div>
      </div>

      <div className="flex flex-wrap gap-1.5">
        {filters.map(f => (
          <button
            key={f.key}
            onClick={() => setFilter(f.key)}
            className={`border px-2.5 py-1 text-2xs ${filter === f.key ? 'border-accent text-accent' : 'border-base-600 text-ink-500 hover:text-ink-100'}`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {loading ? <TableSkeleton rows={8} /> : filtered.length === 0 ? (
        <EmptyState title="No signals match this filter" description="Try a different filter or wait for the next simulated update cycle." />
      ) : (
        <div className="space-y-2">
          {filtered.map(s => (
            <div key={s.id} className="border border-base-700 bg-base-900">
              <button onClick={() => setExpanded(expanded === s.id ? null : s.id)} className="flex w-full items-center justify-between px-4 py-3 text-left">
                <div className="flex items-center gap-3">
                  <StatusPill label={s.direction} tone={s.direction === 'BULLISH' ? 'bull' : 'bear'} />
                  <span className="font-medium text-ink-100">{s.symbol}</span>
                  <StatusPill label={s.status.replace(/_/g, ' ')} tone="info" />
                </div>
                <div className="flex items-center gap-4 text-2xs mono text-ink-500">
                  <span>Score {s.signalScore}</span>
                  <span>Conf {s.modelConfidence}%</span>
                  <span>{new Date(s.generatedAt).toLocaleTimeString()}</span>
                  <span className="text-ink-300">{expanded === s.id ? '▲' : '▼'}</span>
                </div>
              </button>

              {expanded === s.id && (
                <div className="grid grid-cols-1 gap-4 border-t border-base-800 px-4 py-3 md:grid-cols-3">
                  <div className="space-y-1.5 text-2xs">
                    <p className="text-ink-500">Entry zone</p>
                    <p className="mono text-ink-100">{s.entryZoneLow.toFixed(2)} – {s.entryZoneHigh.toFixed(2)}</p>
                    <p className="text-ink-500">Stop loss</p>
                    <p className="mono text-signal-bear">{s.stopLoss.toFixed(2)}</p>
                    <p className="text-ink-500">Targets</p>
                    <p className="mono text-signal-bull">T1 {s.target1.toFixed(2)} / T2 {s.target2.toFixed(2)}</p>
                    <p className="text-ink-500">Risk : Reward</p>
                    <p className="mono text-ink-100">1 : {s.riskReward}</p>
                  </div>
                  <div className="space-y-1 text-2xs">
                    <p className="mb-1 font-semibold text-ink-500 uppercase">Bullish factors</p>
                    <ul className="list-inside list-disc space-y-0.5 text-ink-300">
                      {s.bullishFactors.length ? s.bullishFactors.map((f, i) => <li key={i}>{f}</li>) : <li className="text-ink-500">None</li>}
                    </ul>
                    <p className="mb-1 mt-2 font-semibold text-ink-500 uppercase">Bearish factors</p>
                    <ul className="list-inside list-disc space-y-0.5 text-ink-300">
                      {s.bearishFactors.length ? s.bearishFactors.map((f, i) => <li key={i}>{f}</li>) : <li className="text-ink-500">None</li>}
                    </ul>
                  </div>
                  <div className="space-y-1 text-2xs">
                    <p className="mb-1 font-semibold text-ink-500 uppercase">Evidence</p>
                    <ul className="list-inside list-disc space-y-0.5 text-ink-300">
                      {s.evidence.map((e, i) => <li key={i}>{e}</li>)}
                    </ul>
                    <p className="mb-1 mt-2 font-semibold text-ink-500 uppercase">Invalidation</p>
                    <p className="text-signal-amber">{s.invalidationCondition}</p>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
