import { useEffect, useState } from 'react'
import { getSystemHealth, getAgentRunsSummary, type SystemHealth } from '@/services/admin'
import { getAgents } from '@/services/agents'
import { Panel } from '@/components/common/DataState'
import StatusPill from '@/components/common/StatusPill'
import type { AgentDefinition } from '@/types'

export default function Admin() {
  const [health, setHealth] = useState<SystemHealth | null>(null)
  const [agents, setAgents] = useState<AgentDefinition[]>([])
  const [runs, setRuns] = useState<Awaited<ReturnType<typeof getAgentRunsSummary>>>([])

  useEffect(() => {
    getSystemHealth().then(setHealth)
    getAgents().then(setAgents)
    getAgentRunsSummary().then(setRuns)
  }, [])

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-lg font-semibold text-ink-100">Admin</h1>
        <p className="text-2xs text-ink-500">System health, provider status and audit surfaces. Admin role required.</p>
      </div>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-4">
        <Panel title="Database">
          <StatusPill label={health?.database ?? '…'} tone={health?.database === 'ONLINE' ? 'bull' : 'bear'} />
        </Panel>
        <Panel title="Data Provider">
          <StatusPill label={`MOCK: ${health?.marketProvider ?? '…'}`} tone={health?.marketProvider === 'ONLINE' ? 'bull' : 'bear'} />
        </Panel>
        <Panel title="WebSocket">
          <StatusPill label={health?.websocket ?? '…'} tone="amber" />
        </Panel>
        <Panel title="AI Engine">
          <StatusPill label={health?.aiEngine ?? '…'} tone="amber" />
        </Panel>
      </div>

      <Panel title="Agent Registry">
        <p className="text-2xs text-ink-500">{agents.length} agents registered across {new Set(agents.map(a => a.category)).size} categories.</p>
      </Panel>

      <Panel title="Agent Runs">
        <div className="max-h-64 overflow-y-auto">
          <table className="w-full text-left text-2xs">
            <thead className="text-ink-500">
              <tr><th className="py-1">Agent</th><th>Status</th><th>Last Run</th></tr>
            </thead>
            <tbody>
              {runs.slice(0, 15).map(r => (
                <tr key={r.agentId} className="border-t border-base-800">
                  <td className="py-1.5 text-ink-100">{r.name}</td>
                  <td><StatusPill label={r.status} tone={r.status === 'ACTIVE' ? 'bull' : 'neutral'} /></td>
                  <td className="text-ink-500">{new Date(r.lastRunAt).toLocaleTimeString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Panel>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
        <Panel title="Signals / API Health">
          <p className="text-2xs text-ink-500">All endpoints operating against the Mock Market Data Provider. No external network calls are made in Phase 1.</p>
        </Panel>
        <Panel title="Logs">
          <p className="text-2xs text-ink-500">Audit logging architecture is defined (login, admin actions, signal creation, config changes) but not yet persisted to a real store in Phase 1.</p>
        </Panel>
      </div>
    </div>
  )
}
