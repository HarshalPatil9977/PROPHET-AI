// ============================================================
// WEIGHTED CONSENSUS SCORING
// ------------------------------------------------------------
// Lightweight aggregation of individual AgentOutputs into a single
// consensus reading. This is a Phase 1 placeholder for the full
// Multi-Agent Debate Engine + Master CIO defined for Phase 4 --
// it exists so the Dashboard and Signal Center have something real
// to render, clearly labeled as SIMULATED AI CONSENSUS.
// ============================================================

import type { AgentDefinition, AgentOutput, Opinion } from '@/types'
import { AGENT_REGISTRY } from '@/data/mock/agentRegistry'

export interface ConsensusResult {
  symbol: string
  overallScore: number // -100..100
  overallOpinion: Opinion
  agentCount: number
  agreementPercent: number // % of agents aligned with majority opinion
  riskLevel: 'LOW' | 'MODERATE' | 'ELEVATED'
  bullishFactors: string[]
  bearishFactors: string[]
  evidence: string[]
  risks: string[]
  invalidationCondition: string
}

const weightById = new Map<string, number>(AGENT_REGISTRY.map((a: AgentDefinition) => [a.id, a.weight]))

export function computeConsensus(symbol: string, outputs: AgentOutput[]): ConsensusResult {
  if (outputs.length === 0) {
    return {
      symbol, overallScore: 0, overallOpinion: 'NEUTRAL', agentCount: 0, agreementPercent: 0,
      riskLevel: 'MODERATE', bullishFactors: [], bearishFactors: [], evidence: [], risks: [],
      invalidationCondition: 'Insufficient agent data.',
    }
  }

  let weightedSum = 0
  let weightTotal = 0
  const opinionCounts: Record<Opinion, number> = { BULLISH: 0, BEARISH: 0, NEUTRAL: 0 }

  for (const o of outputs) {
    const w = weightById.get(o.agentId) ?? 0.5
    weightedSum += o.score * w
    weightTotal += w
    opinionCounts[o.opinion]++
  }

  const overallScore = Math.round(weightedSum / (weightTotal || 1))
  const overallOpinion: Opinion = overallScore > 12 ? 'BULLISH' : overallScore < -12 ? 'BEARISH' : 'NEUTRAL'
  const majorityCount = Math.max(opinionCounts.BULLISH, opinionCounts.BEARISH, opinionCounts.NEUTRAL)
  const agreementPercent = Math.round((majorityCount / outputs.length) * 100)

  const riskLevel: ConsensusResult['riskLevel'] =
    agreementPercent < 50 ? 'ELEVATED' : agreementPercent < 70 ? 'MODERATE' : 'LOW'

  // Pull the strongest bull/bear evidence by |score| * confidence.
  const sorted = [...outputs].sort((a, b) => Math.abs(b.score) * b.confidence - Math.abs(a.score) * a.confidence)
  const bullishFactors = sorted.filter(o => o.opinion === 'BULLISH').slice(0, 4).flatMap(o => o.bullishFactors).slice(0, 5)
  const bearishFactors = sorted.filter(o => o.opinion === 'BEARISH').slice(0, 4).flatMap(o => o.bearishFactors).slice(0, 5)
  const evidence = Array.from(new Set(sorted.slice(0, 6).flatMap(o => o.evidence))).slice(0, 6)
  const risks = Array.from(new Set(sorted.slice(0, 5).flatMap(o => o.risks))).slice(0, 3)

  const invalidationCondition = overallOpinion === 'BULLISH'
    ? sorted.find(o => o.opinion === 'BULLISH')?.invalidationCondition ?? 'No invalidation condition available.'
    : overallOpinion === 'BEARISH'
      ? sorted.find(o => o.opinion === 'BEARISH')?.invalidationCondition ?? 'No invalidation condition available.'
      : 'Range breakout in either direction invalidates the neutral read.'

  return {
    symbol, overallScore, overallOpinion, agentCount: outputs.length, agreementPercent, riskLevel,
    bullishFactors, bearishFactors, evidence, risks, invalidationCondition,
  }
}
