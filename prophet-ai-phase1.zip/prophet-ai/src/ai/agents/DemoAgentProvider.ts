// ============================================================
// DEMO AGENT PROVIDER
// ------------------------------------------------------------
// Simulates each registered agent producing a structured, validated
// AgentOutput. This is SIMULATED AGENT OUTPUT, not real AI research --
// it exists so downstream layers (debate, scoring, signals, backtest,
// paper trading) have a realistic structured contract to consume
// before real inference is wired in during a later phase.
// ============================================================

import type { AgentDefinition, AgentOutput, Opinion } from '@/types'
import { validateAgentOutput } from '@/types'
import { AGENT_REGISTRY } from '@/data/mock/agentRegistry'
import { generateCandles } from '@/data/mock/priceEngine'

function mulberry32(seed: number) {
  return function () {
    seed |= 0
    seed = (seed + 0x6d2b79f5) | 0
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

function hashString(s: string): number {
  let h = 0
  for (let i = 0; i < s.length; i++) h = (Math.imul(31, h) + s.charCodeAt(i)) | 0
  return h
}

const EVIDENCE_BANK: Record<string, string[]> = {
  Technical: ['Price holding above 20 EMA on the daily chart', 'RSI reclaiming the 50 midline', 'Higher low structure intact since the last swing low'],
  Options: ['Fresh call OI build-up at the near ATM strike', 'PCR shifted above 1.1 over the last two sessions', 'IV skew flattening on the call side'],
  Quant: ['Z-score deviation exceeding 1.5 std from 20-day mean', 'Momentum factor rank in the top decile', 'Realized volatility compressing versus 30-day average'],
  Fundamental: ['Revenue growth ahead of sector median last quarter', 'Operating margin expansion for two consecutive quarters', 'FII holding increased in the latest filing'],
  Macro: ['Crude oil pulling back, easing input-cost pressure', 'INR stabilizing against the dollar this week', 'System liquidity remains in surplus'],
  Intelligence: ['Positive analyst commentary following the recent update', 'Sector rotation flows turning favorable', 'No material adverse news detected in the last 48 hours'],
  Risk: ['Liquidity depth adequate at current position size', 'Correlation to index remains within normal range', 'No major event risk in the next 3 sessions'],
  Master: ['Cross-category evidence alignment above threshold', 'Debate consensus favors directional bias', 'Risk-adjusted conviction meets minimum bar'],
}

const RISK_BANK = [
  'A sudden reversal in broader index direction could invalidate the setup.',
  'Thin liquidity around this level could cause slippage on entry/exit.',
  'An unexpected macro data print could override the technical picture.',
  'Earnings or corporate action risk within the signal window.',
]

function pick<T>(rand: () => number, arr: T[]): T {
  return arr[Math.floor(rand() * arr.length)]
}

function opinionFromScore(score: number): Opinion {
  if (score > 15) return 'BULLISH'
  if (score < -15) return 'BEARISH'
  return 'NEUTRAL'
}

/** Deterministic per-agent-per-symbol-per-hour simulated research opinion. */
export function generateAgentOutput(agent: AgentDefinition, symbol: string): AgentOutput {
  const hourBucket = Math.floor(Date.now() / 3_600_000)
  const seed = hashString(`${agent.id}:${symbol}:${hourBucket}`)
  const rand = mulberry32(seed)

  // Derive a lightweight signal from actual (simulated) price action so
  // agent opinions are loosely consistent with the chart, not pure noise.
  const candles = generateCandles(symbol, '1D', 10)
  const first = candles[0].close
  const last = candles[candles.length - 1].close
  const trendPct = ((last - first) / first) * 100

  const noise = (rand() - 0.5) * 40
  const score = Math.max(-100, Math.min(100, trendPct * 8 + noise))
  const confidence = Math.round(50 + rand() * 45)

  const bank = EVIDENCE_BANK[agent.category] ?? EVIDENCE_BANK.Technical
  const evidenceCount = 2 + Math.floor(rand() * 2)
  const evidence = Array.from({ length: evidenceCount }, () => pick(rand, bank))

  const opinion = opinionFromScore(score)
  const bullishFactors = opinion !== 'BEARISH' ? evidence.slice(0, Math.ceil(evidence.length / 2)) : []
  const bearishFactors = opinion !== 'BULLISH' ? evidence.slice(Math.ceil(evidence.length / 2)) : []

  const output: AgentOutput = {
    id: `out-${agent.id}-${symbol}-${hourBucket}`,
    symbol,
    agentId: agent.id,
    timestamp: Date.now(),
    opinion,
    score: Math.round(score),
    confidence,
    bullishFactors: bullishFactors.length ? bullishFactors : [pick(rand, bank)],
    bearishFactors,
    evidence,
    risks: [pick(rand, RISK_BANK)],
    timeframe: pick(rand, ['Intraday', 'Swing (3-5 days)', 'Positional (2-4 weeks)']),
    invalidationCondition: opinion === 'BULLISH'
      ? `Close below the recent swing low invalidates the bullish thesis on ${symbol}.`
      : opinion === 'BEARISH'
        ? `Close above the recent swing high invalidates the bearish thesis on ${symbol}.`
        : `A decisive break of the current range invalidates the neutral thesis on ${symbol}.`,
    simulated: true,
  }

  const errors = validateAgentOutput(output)
  if (errors.length) {
    throw new Error(`Invalid simulated agent output for ${agent.id}/${symbol}: ${errors.join(', ')}`)
  }
  return output
}

export function generateAllAgentOutputs(symbol: string): AgentOutput[] {
  return AGENT_REGISTRY.filter(a => a.enabled && a.category !== 'Master').map(a => generateAgentOutput(a, symbol))
}
