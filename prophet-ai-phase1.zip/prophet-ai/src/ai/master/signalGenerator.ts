// ============================================================
// DEMO SIGNAL GENERATOR
// ------------------------------------------------------------
// Turns a ConsensusResult + current quote into a structured, validated
// Signal for the Signal Center. This is a Phase 1 stand-in for the full
// Bull/Bear Debate -> Risk Engine -> Master CIO pipeline (Phase 4).
// All output is DEMO DATA and clearly marked `simulated: true`.
// ============================================================

import type { Quote, Signal, SignalStatus } from '@/types'
import { validateSignal } from '@/types'
import type { ConsensusResult } from '@/ai/scoring/consensus'

function statusFromScore(agreementPercent: number, score: number): SignalStatus {
  if (Math.abs(score) < 12) return 'WATCH'
  if (agreementPercent < 55) return 'DEVELOPING'
  if (agreementPercent < 70) return 'CONFIRMATION_PENDING'
  return 'CONFIRMED'
}

export function generateSignalFromConsensus(quote: Quote, consensus: ConsensusResult): Signal | null {
  if (consensus.overallOpinion === 'NEUTRAL') return null

  const direction = consensus.overallOpinion === 'BULLISH' ? 'BULLISH' : 'BEARISH'
  const atrEstimate = quote.ltp * 0.012
  const entryZoneLow = direction === 'BULLISH' ? quote.ltp - atrEstimate * 0.3 : quote.ltp - atrEstimate * 0.7
  const entryZoneHigh = direction === 'BULLISH' ? quote.ltp + atrEstimate * 0.3 : quote.ltp + atrEstimate * 0.3
  const stopLoss = direction === 'BULLISH' ? entryZoneLow - atrEstimate * 1.4 : entryZoneHigh + atrEstimate * 1.4
  const risk = Math.abs((direction === 'BULLISH' ? entryZoneHigh : entryZoneLow) - stopLoss)
  const target1 = direction === 'BULLISH' ? entryZoneHigh + risk * 1.5 : entryZoneLow - risk * 1.5
  const target2 = direction === 'BULLISH' ? entryZoneHigh + risk * 2.5 : entryZoneLow - risk * 2.5
  const riskReward = Math.round((Math.abs(target1 - entryZoneHigh) / risk) * 10) / 10

  const signal: Signal = {
    id: `sig-${quote.symbol}-${Math.floor(Date.now() / 3_600_000)}`,
    symbol: quote.symbol,
    direction,
    signalScore: Math.min(100, Math.abs(consensus.overallScore)),
    modelConfidence: consensus.agreementPercent,
    entryZoneLow: round2(entryZoneLow),
    entryZoneHigh: round2(entryZoneHigh),
    stopLoss: round2(stopLoss),
    target1: round2(target1),
    target2: round2(target2),
    riskReward,
    timeframe: 'Swing (3-5 days)',
    status: statusFromScore(consensus.agreementPercent, consensus.overallScore),
    generatedAt: Date.now(),
    bullishFactors: consensus.bullishFactors,
    bearishFactors: consensus.bearishFactors,
    evidence: consensus.evidence,
    risk: consensus.risks[0] ?? 'Standard market risk applies.',
    invalidationCondition: consensus.invalidationCondition,
    simulated: true,
  }

  const errors = validateSignal(signal)
  if (errors.length) throw new Error(`Invalid generated signal for ${quote.symbol}: ${errors.join(', ')}`)
  return signal
}

function round2(n: number) {
  return Math.round(n * 100) / 100
}
