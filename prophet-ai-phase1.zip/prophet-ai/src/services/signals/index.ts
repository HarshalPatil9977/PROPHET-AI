import { marketDataService } from '@/services/marketData'
import { generateAllAgentOutputs } from '@/ai/agents/DemoAgentProvider'
import { computeConsensus } from '@/ai/scoring/consensus'
import { generateSignalFromConsensus } from '@/ai/master/signalGenerator'
import type { Signal } from '@/types'
import { INSTRUMENTS } from '@/data/mock/instruments'

const SIGNAL_UNIVERSE = INSTRUMENTS.filter(i => i.type === 'EQUITY').map(i => i.symbol)

export async function getSignals(): Promise<Signal[]> {
  const signals: Signal[] = []
  for (const symbol of SIGNAL_UNIVERSE) {
    const quote = await marketDataService.getQuote(symbol)
    const outputs = generateAllAgentOutputs(symbol)
    const consensus = computeConsensus(symbol, outputs)
    const signal = generateSignalFromConsensus(quote, consensus)
    if (signal) signals.push(signal)
  }
  return signals.sort((a, b) => b.signalScore - a.signalScore)
}

export async function getSignalsForSymbol(symbol: string) {
  const quote = await marketDataService.getQuote(symbol)
  const outputs = generateAllAgentOutputs(symbol)
  const consensus = computeConsensus(symbol, outputs)
  const signal = generateSignalFromConsensus(quote, consensus)
  return { quote, outputs, consensus, signal }
}
