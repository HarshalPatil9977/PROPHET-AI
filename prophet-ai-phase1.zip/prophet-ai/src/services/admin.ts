import { AGENT_REGISTRY } from '@/data/mock/agentRegistry'

export interface SystemHealth {
  database: 'ONLINE' | 'OFFLINE'
  marketProvider: 'ONLINE' | 'OFFLINE'
  websocket: 'ONLINE' | 'OFFLINE' | 'SIMULATED'
  aiEngine: 'ONLINE' | 'SIMULATION_MODE' | 'OFFLINE'
}

export async function getSystemHealth(): Promise<SystemHealth> {
  return {
    database: 'ONLINE', // localStorage stand-in reports as online for demo purposes
    marketProvider: 'ONLINE',
    websocket: 'SIMULATED',
    aiEngine: 'SIMULATION_MODE',
  }
}

export async function getAgentRunsSummary() {
  return AGENT_REGISTRY.map(a => ({
    agentId: a.id,
    name: a.name,
    status: a.status,
    lastRunAt: Date.now() - Math.floor(Math.random() * 0) - 60_000, // stable-ish demo value
  }))
}
