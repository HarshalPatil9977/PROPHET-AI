// ============================================================
// WATCHLIST SERVICE
// ------------------------------------------------------------
// Phase 1 persists watchlists to browser localStorage as a stand-in
// for the `watchlists` / `watchlist_items` Postgres tables (see
// db/schema.sql). Swap this module's internals for real API calls
// once the backend is wired up -- the function signatures won't change.
// ============================================================

import type { Watchlist } from '@/types'

const STORAGE_KEY = 'prophet_ai_watchlists_v1'

function loadAll(): Watchlist[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (!raw) return seedDefault()
    return JSON.parse(raw)
  } catch {
    return seedDefault()
  }
}

function saveAll(lists: Watchlist[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(lists))
}

function seedDefault(): Watchlist[] {
  const now = new Date().toISOString()
  const defaults: Watchlist = {
    id: 'wl-default',
    userId: 'demo-user',
    name: 'My Watchlist',
    createdAt: now,
    updatedAt: now,
    items: ['NIFTY', 'BANKNIFTY', 'RELIANCE', 'HDFCBANK', 'TCS', 'INFY'].map((symbol, i) => ({
      id: `wli-default-${i}`,
      watchlistId: 'wl-default',
      symbol,
      addedAt: now,
    })),
  }
  saveAll([defaults])
  return [defaults]
}

export async function getWatchlists(): Promise<Watchlist[]> {
  return loadAll()
}

export async function createWatchlist(name: string): Promise<Watchlist> {
  const lists = loadAll()
  const now = new Date().toISOString()
  const list: Watchlist = { id: `wl-${crypto.randomUUID()}`, userId: 'demo-user', name, createdAt: now, updatedAt: now, items: [] }
  lists.push(list)
  saveAll(lists)
  return list
}

export async function renameWatchlist(id: string, name: string): Promise<void> {
  const lists = loadAll()
  const list = lists.find(l => l.id === id)
  if (list) { list.name = name; list.updatedAt = new Date().toISOString(); saveAll(lists) }
}

export async function deleteWatchlist(id: string): Promise<void> {
  saveAll(loadAll().filter(l => l.id !== id))
}

export async function addSymbol(watchlistId: string, symbol: string): Promise<void> {
  const lists = loadAll()
  const list = lists.find(l => l.id === watchlistId)
  if (list && !list.items.some(i => i.symbol === symbol)) {
    list.items.push({ id: `wli-${crypto.randomUUID()}`, watchlistId, symbol, addedAt: new Date().toISOString() })
    list.updatedAt = new Date().toISOString()
    saveAll(lists)
  }
}

export async function removeSymbol(watchlistId: string, symbol: string): Promise<void> {
  const lists = loadAll()
  const list = lists.find(l => l.id === watchlistId)
  if (list) {
    list.items = list.items.filter(i => i.symbol !== symbol)
    list.updatedAt = new Date().toISOString()
    saveAll(lists)
  }
}
