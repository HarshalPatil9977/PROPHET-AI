import { marketDataService } from '@/services/marketData'
import { generateAllAgentOutputs } from '@/ai/agents/DemoAgentProvider'
import { computeConsensus } from '@/ai/scoring/consensus'
import { generateCandles } from '@/data/mock/priceEngine'
import { INSTRUMENTS } from '@/data/mock/instruments'

export interface ScannerRow {
  symbol: string
  price: number
  change: number
  volume: number
  rsiApprox: number
  vwapApprox: number
  trend: 'UP' | 'DOWN' | 'SIDEWAYS'
  aiScore: number
  confidence: number
  signal: 'BULLISH' | 'BEARISH' | 'NEUTRAL'
  risk: 'LOW' | 'MODERATE' | 'ELEVATED'
}

// Cheap RSI approximation for the scanner table (not the full indicator engine).
function approxRSI(closes: number[]): number {
  let gains = 0, losses = 0
  for (let i = 1; i < closes.length; i++) {
    const diff = closes[i] - closes[i - 1]
    if (diff >= 0) gains += diff
    else losses -= diff
  }
  const avgGain = gains / (closes.length - 1)
  const avgLoss = losses / (closes.length - 1) || 0.0001
  const rs = avgGain / avgLoss
  return Math.round(100 - 100 / (1 + rs))
}

export async function getScannerRows(): Promise<ScannerRow[]> {
  const symbols = INSTRUMENTS.filter(i => i.type === 'EQUITY').map(i => i.symbol)
  const rows: ScannerRow[] = []
  for (const symbol of symbols) {
    const quote = await marketDataService.getQuote(symbol)
    const daily = generateCandles(symbol, '1D', 14)
    const closes = daily.map(c => c.close)
    const vwapApprox = daily.reduce((s, c) => s + (c.high + c.low + c.close) / 3, 0) / daily.length
    const rsi = approxRSI(closes)
    const trend: ScannerRow['trend'] = closes[closes.length - 1] > closes[0] * 1.01
      ? 'UP' : closes[closes.length - 1] < closes[0] * 0.99 ? 'DOWN' : 'SIDEWAYS'

    const outputs = generateAllAgentOutputs(symbol)
    const consensus = computeConsensus(symbol, outputs)

    rows.push({
      symbol,
      price: quote.ltp,
      change: quote.changePercent,
      volume: quote.volume,
      rsiApprox: rsi,
      vwapApprox: Math.round(vwapApprox * 100) / 100,
      trend,
      aiScore: consensus.overallScore,
      confidence: consensus.agreementPercent,
      signal: consensus.overallOpinion,
      risk: consensus.riskLevel,
    })
  }
  return rows
}
