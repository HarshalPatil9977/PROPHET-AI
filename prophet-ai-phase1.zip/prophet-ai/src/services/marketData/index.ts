import { mockMarketDataProvider } from '@/data/providers/MockMarketDataProvider'
import type { MarketDataProvider } from '@/types'

// Swap this single line to point the whole app at a licensed provider.
export const marketDataService: MarketDataProvider = mockMarketDataProvider
