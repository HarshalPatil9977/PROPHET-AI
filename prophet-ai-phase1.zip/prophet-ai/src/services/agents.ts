import { AGENT_REGISTRY } from '@/data/mock/agentRegistry'
import type { AgentDefinition } from '@/types'

export async function getAgents(): Promise<AgentDefinition[]> {
  return AGENT_REGISTRY
}

export async function getAgentById(id: string): Promise<AgentDefinition | undefined> {
  return AGENT_REGISTRY.find(a => a.id === id)
}
