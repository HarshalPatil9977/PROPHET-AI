// ============================================================
// AUTH SERVICE (SCAFFOLD)
// ------------------------------------------------------------
// Demo-mode auth backed by localStorage. Structured so a real
// provider (Supabase, Auth0, custom JWT backend) can be dropped in
// behind the same three functions without touching call sites.
// No secrets are ever read or embedded here.
// ============================================================

import type { AuthUser, UserRole } from '@/types'

const STORAGE_KEY = 'prophet_ai_session_v1'

const DEMO_USERS: Record<string, { password: string; user: AuthUser }> = {
  'admin@prophet.ai': { password: 'admin123', user: { id: 'u-admin', email: 'admin@prophet.ai', name: 'Admin User', role: 'admin' } },
  'analyst@prophet.ai': { password: 'analyst123', user: { id: 'u-analyst', email: 'analyst@prophet.ai', name: 'Analyst User', role: 'analyst' } },
  'demo@prophet.ai': { password: 'demo1234', user: { id: 'u-demo', email: 'demo@prophet.ai', name: 'Demo User', role: 'user' } },
}

export async function login(email: string, password: string): Promise<AuthUser> {
  const record = DEMO_USERS[email.toLowerCase()]
  if (!record || record.password !== password) {
    throw new Error('Invalid email or password.')
  }
  localStorage.setItem(STORAGE_KEY, JSON.stringify(record.user))
  return record.user
}

export async function signup(email: string, name: string, _password: string, role: UserRole = 'user'): Promise<AuthUser> {
  const user: AuthUser = { id: `u-${crypto.randomUUID()}`, email, name, role }
  localStorage.setItem(STORAGE_KEY, JSON.stringify(user))
  return user
}

export async function logout(): Promise<void> {
  localStorage.removeItem(STORAGE_KEY)
}

export function getSession(): AuthUser | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    return raw ? JSON.parse(raw) : null
  } catch {
    return null
  }
}

export const DEMO_CREDENTIALS = Object.entries(DEMO_USERS).map(([email, v]) => ({ email, password: v.password, role: v.user.role }))
