import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { AuthProvider } from '@/context/AuthContext'
import { RealtimeProvider } from '@/context/RealtimeContext'
import { DemoModeProvider } from '@/context/DemoModeContext'
import AppShell from '@/components/layout/AppShell'
import ProtectedRoute from '@/components/common/ProtectedRoute'

import Login from '@/pages/Login'
import Dashboard from '@/pages/Dashboard'
import Markets from '@/pages/Markets'
import Signals from '@/pages/Signals'
import Scanner from '@/pages/Scanner'
import Watchlists from '@/pages/Watchlists'
import Agents from '@/pages/Agents'
import Admin from '@/pages/Admin'
import Placeholder from '@/pages/Placeholder'

const PLACEHOLDER_ROUTES = [
  '/research', '/technical', '/fundamentals', '/news', '/regime', '/strategies',
  '/backtesting', '/paper-trading', '/portfolio', '/ai-chat', '/reports', '/performance', '/alerts', '/options',
]

export default function App() {
  return (
    <AuthProvider>
      <DemoModeProvider>
        <RealtimeProvider>
          <BrowserRouter>
            <Routes>
              <Route path="/login" element={<Login />} />
              <Route path="/" element={<Navigate to="/dashboard" replace />} />

              <Route element={<ProtectedRoute><AppShell /></ProtectedRoute>}>
                <Route path="/dashboard" element={<Dashboard />} />
                <Route path="/markets" element={<Markets />} />
                <Route path="/signals" element={<Signals />} />
                <Route path="/scanner" element={<Scanner />} />
                <Route path="/watchlists" element={<Watchlists />} />
                <Route path="/agents" element={<Agents />} />
                <Route path="/admin" element={<ProtectedRoute requiredRole="admin"><Admin /></ProtectedRoute>} />
                {PLACEHOLDER_ROUTES.map(r => <Route key={r} path={r} element={<Placeholder />} />)}
                <Route path="*" element={<Placeholder />} />
              </Route>
            </Routes>
          </BrowserRouter>
        </RealtimeProvider>
      </DemoModeProvider>
    </AuthProvider>
  )
}
