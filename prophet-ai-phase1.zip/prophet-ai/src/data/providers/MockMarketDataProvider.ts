// ============================================================
// MOCK MARKET DATA PROVIDER
// ------------------------------------------------------------
// Implements MarketDataProvider using the deterministic price engine.
// This is DEMO DATA -- swap this class for a licensed production
// provider (e.g. a broker/exchange feed) without touching UI code,
// since all consumers depend only on the MarketDataProvider interface.
// ============================================================

import type {
  MarketDataProvider, Quote, Candle, Timeframe, MarketOverview,
  SectorPerformance, MarketBreadth, Instrument, MarketDepth,
} from '@/types'
import { INSTRUMENTS, SECTORS } from '@/data/mock/instruments'
import { generateCandles } from '@/data/mock/priceEngine'

function marketStatusNow(): 'PRE_OPEN' | 'OPEN' | 'CLOSED' {
  const now = new Date()
  const ist = new Date(now.toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }))
  const mins = ist.getHours() * 60 + ist.getMinutes()
  const day = ist.getDay()
  if (day === 0 || day === 6) return 'CLOSED'
  if (mins < 555) return 'CLOSED' // before 9:15
  if (mins < 555 + 5) return 'PRE_OPEN'
  if (mins > 930) return 'CLOSED' // after 15:30
  return 'OPEN'
}

function quoteFromCandles(symbol: string): Quote {
  const daily = generateCandles(symbol, '1D', 2)
  const today = daily[daily.length - 1]
  const prev = daily[daily.length - 2] ?? today
  const intraday = generateCandles(symbol, '5m', 1)[0]
  const ltp = intraday.close
  const change = ltp - prev.close
  const changePercent = (change / prev.close) * 100

  return {
    symbol,
    ltp: round2(ltp),
    change: round2(change),
    changePercent: round2(changePercent),
    open: round2(today.open),
    high: round2(Math.max(today.high, ltp)),
    low: round2(Math.min(today.low, ltp)),
    prevClose: round2(prev.close),
    volume: today.volume,
    timestamp: Date.now(),
    marketStatus: marketStatusNow(),
  }
}

function round2(n: number) {
  return Math.round(n * 100) / 100
}

export class MockMarketDataProvider implements MarketDataProvider {
  async getQuote(symbol: string): Promise<Quote> {
    return quoteFromCandles(symbol)
  }

  async getQuotes(symbols: string[]): Promise<Quote[]> {
    return symbols.map(quoteFromCandles)
  }

  async getHistoricalData(symbol: string, timeframe: Timeframe, bars: number): Promise<Candle[]> {
    return generateCandles(symbol, timeframe, bars)
  }

  async getMarketOverview(): Promise<MarketOverview> {
    const indexSymbols = ['NIFTY', 'BANKNIFTY', 'SENSEX', 'FINNIFTY', 'INDIAVIX']
    const indices = indexSymbols.map(quoteFromCandles)
    return {
      indices,
      breadth: await this.getMarketBreadth(),
      sectorPerformance: await this.getSectorPerformance(),
      timestamp: Date.now(),
    }
  }

  async getSectorPerformance(): Promise<SectorPerformance[]> {
    return SECTORS.filter(s => s !== 'Index' && s !== 'Volatility').map(sector => {
      const members = INSTRUMENTS.filter(i => i.sector === sector)
      const quotes = members.map(m => quoteFromCandles(m.symbol))
      const avgChange = quotes.reduce((sum, q) => sum + q.changePercent, 0) / (quotes.length || 1)
      const advancers = quotes.filter(q => q.changePercent >= 0).length
      return {
        sector,
        changePercent: round2(avgChange),
        advancers,
        decliners: quotes.length - advancers,
      }
    })
  }

  async getMarketBreadth(): Promise<MarketBreadth> {
    const equities = INSTRUMENTS.filter(i => i.type === 'EQUITY')
    const quotes = equities.map(e => quoteFromCandles(e.symbol))
    const advancers = quotes.filter(q => q.changePercent > 0).length
    const decliners = quotes.filter(q => q.changePercent < 0).length
    const unchanged = quotes.length - advancers - decliners
    return {
      advancers, decliners, unchanged,
      advanceDeclineRatio: decliners === 0 ? advancers : round2(advancers / decliners),
    }
  }

  async getInstrumentUniverse(): Promise<Instrument[]> {
    return INSTRUMENTS
  }

  async getMarketDepth(symbol: string): Promise<MarketDepth> {
    const q = quoteFromCandles(symbol)
    const tick = Math.max(q.ltp * 0.0005, 0.05)
    const mkLevel = (i: number, side: 1 | -1) => ({
      price: round2(q.ltp + side * tick * (i + 1)),
      quantity: Math.floor(50 + Math.random() * 500) * 0 + (100 + i * 37) * 10, // deterministic-ish
      orders: 3 + i,
    })
    return {
      symbol,
      bids: Array.from({ length: 5 }, (_, i) => mkLevel(i, -1)),
      asks: Array.from({ length: 5 }, (_, i) => mkLevel(i, 1)),
      timestamp: Date.now(),
    }
  }
}

export const mockMarketDataProvider = new MockMarketDataProvider()
