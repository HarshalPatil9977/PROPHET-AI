// ============================================================
// AGENT REGISTRY -- 60 AGENT DEFINITIONS
// ------------------------------------------------------------
// Phase 1 registers the full roster of agents. It does NOT run real
// AI inference. See DemoAgentProvider for simulated structured output.
// ============================================================

import type { AgentDefinition, AgentCategory } from '@/types'

interface Seed { name: string; category: AgentCategory; description: string }

const SEEDS: Seed[] = [
  // ---- Technical (10) ----
  { name: 'Trend Structure Analyst', category: 'Technical', description: 'Reads higher-timeframe trend structure, swing highs/lows and market phase.' },
  { name: 'VWAP Analyst', category: 'Technical', description: 'Tracks price behavior relative to session VWAP and anchored VWAP bands.' },
  { name: 'Moving Average Analyst', category: 'Technical', description: 'Evaluates EMA 20/50/200 alignment, crossovers and slope.' },
  { name: 'RSI Momentum Analyst', category: 'Technical', description: 'Assesses RSI level, divergence and overbought/oversold regimes.' },
  { name: 'MACD Analyst', category: 'Technical', description: 'Evaluates MACD histogram momentum and signal-line crossovers.' },
  { name: 'Support/Resistance Analyst', category: 'Technical', description: 'Maps horizontal supply/demand zones and confluence levels.' },
  { name: 'Candlestick Pattern Analyst', category: 'Technical', description: 'Detects classical reversal/continuation candlestick patterns.' },
  { name: 'Volume Profile Analyst', category: 'Technical', description: 'Reads volume-at-price nodes, value area and point of control.' },
  { name: 'Volatility Bands Analyst', category: 'Technical', description: 'Tracks Bollinger Band width, squeezes and mean-reversion setups.' },
  { name: 'Multi-Timeframe Confluence Analyst', category: 'Technical', description: 'Cross-checks signal agreement across intraday and swing timeframes.' },

  // ---- Options (8) ----
  { name: 'Open Interest Analyst', category: 'Options', description: 'Reads OI build-up/unwind across strikes to infer positioning.' },
  { name: 'PCR Analyst', category: 'Options', description: 'Tracks put-call ratio shifts as a contrarian/confirming signal.' },
  { name: 'Max Pain Analyst', category: 'Options', description: 'Estimates the max-pain strike and its pull into expiry.' },
  { name: 'IV Skew Analyst', category: 'Options', description: 'Analyzes implied volatility skew across strikes and tenors.' },
  { name: 'Options Flow Analyst', category: 'Options', description: 'Monitors large block trades and unusual options activity.' },
  { name: 'Gamma Exposure Analyst', category: 'Options', description: 'Estimates dealer gamma positioning and pinning risk.' },
  { name: 'Straddle/Strangle Analyst', category: 'Options', description: 'Reads implied-move pricing from ATM straddle premiums.' },
  { name: 'Options Chain Structure Analyst', category: 'Options', description: 'Evaluates bid-ask spreads and liquidity depth across the chain.' },

  // ---- Quant (8) ----
  { name: 'Statistical Arbitrage Analyst', category: 'Quant', description: 'Screens for mean-reversion pairs and z-score dislocations.' },
  { name: 'Momentum Factor Analyst', category: 'Quant', description: 'Ranks cross-sectional price momentum factors.' },
  { name: 'Volatility Regime Analyst', category: 'Quant', description: 'Classifies realized volatility regime and clustering.' },
  { name: 'Correlation Analyst', category: 'Quant', description: 'Tracks rolling correlation shifts across sectors and indices.' },
  { name: 'Seasonality Analyst', category: 'Quant', description: 'Evaluates historical calendar/seasonal price tendencies.' },
  { name: 'Mean Reversion Analyst', category: 'Quant', description: 'Detects statistically stretched price deviations from fair value.' },
  { name: 'Beta Sensitivity Analyst', category: 'Quant', description: 'Assesses instrument beta and sensitivity to index moves.' },
  { name: 'Backtest Signal Analyst', category: 'Quant', description: 'Cross-references live setups against historical analog performance.' },

  // ---- Fundamental (8) ----
  { name: 'Earnings Analyst', category: 'Fundamental', description: 'Tracks earnings trend, surprises and guidance revisions.' },
  { name: 'Valuation Analyst', category: 'Fundamental', description: 'Evaluates P/E, P/B and EV/EBITDA relative to historical bands.' },
  { name: 'Balance Sheet Analyst', category: 'Fundamental', description: 'Assesses leverage, liquidity and balance-sheet quality.' },
  { name: 'Cash Flow Analyst', category: 'Fundamental', description: 'Tracks free cash flow trend and capital allocation.' },
  { name: 'Sector Comparative Analyst', category: 'Fundamental', description: 'Benchmarks fundamentals against sector peers.' },
  { name: 'Management Guidance Analyst', category: 'Fundamental', description: 'Monitors management commentary and forward guidance tone.' },
  { name: 'Institutional Holding Analyst', category: 'Fundamental', description: 'Tracks FII/DII/mutual fund ownership shifts.' },
  { name: 'Dividend & Buyback Analyst', category: 'Fundamental', description: 'Evaluates capital-return policy and yield sustainability.' },

  // ---- Macro (8) ----
  { name: 'Interest Rate Analyst', category: 'Macro', description: 'Tracks RBI policy stance and yield-curve implications.' },
  { name: 'Inflation Analyst', category: 'Macro', description: 'Monitors CPI/WPI trends and real-rate impact.' },
  { name: 'Currency Analyst', category: 'Macro', description: 'Assesses USD/INR trend and its sector-level pass-through.' },
  { name: 'Global Cues Analyst', category: 'Macro', description: 'Reads overnight US/Asia market cues and futures.' },
  { name: 'Commodity Analyst', category: 'Macro', description: 'Tracks crude oil, metals and input-cost implications.' },
  { name: 'Liquidity Analyst', category: 'Macro', description: 'Monitors system liquidity, FII/DII flows and credit growth.' },
  { name: 'Geopolitical Risk Analyst', category: 'Macro', description: 'Flags geopolitical developments relevant to Indian markets.' },
  { name: 'Fiscal Policy Analyst', category: 'Macro', description: 'Tracks government spending, deficit and policy announcements.' },

  // ---- Intelligence / Sentiment (10) ----
  { name: 'News Sentiment Analyst', category: 'Intelligence', description: 'Scores real-time news sentiment for the instrument and sector.' },
  { name: 'Social Sentiment Analyst', category: 'Intelligence', description: 'Tracks retail sentiment shifts across public forums.' },
  { name: 'Analyst Rating Tracker', category: 'Intelligence', description: 'Aggregates sell-side rating and target-price changes.' },
  { name: 'Corporate Action Analyst', category: 'Intelligence', description: 'Flags splits, bonuses, M&A and other corporate actions.' },
  { name: 'Insider Activity Analyst', category: 'Intelligence', description: 'Monitors promoter/insider buying and selling activity.' },
  { name: 'Sector Rotation Analyst', category: 'Intelligence', description: 'Detects capital rotation between sectors and themes.' },
  { name: 'Market Regime Classifier', category: 'Intelligence', description: 'Classifies broad market regime: trending, choppy or volatile.' },
  { name: 'Peer Comparison Analyst', category: 'Intelligence', description: 'Benchmarks relative strength against direct peers.' },
  { name: 'Event Calendar Analyst', category: 'Intelligence', description: 'Flags upcoming earnings, expiry and macro-event risk windows.' },
  { name: 'Historical Analog Analyst', category: 'Intelligence', description: 'Matches current setup to similar historical price structures.' },

  // ---- Risk (6) ----
  { name: 'Position Sizing Analyst', category: 'Risk', description: 'Recommends position sizing bounds based on volatility and account risk.' },
  { name: 'Drawdown Risk Analyst', category: 'Risk', description: 'Evaluates potential drawdown against historical volatility bands.' },
  { name: 'Liquidity Risk Analyst', category: 'Risk', description: 'Flags thin liquidity, wide spreads and slippage risk.' },
  { name: 'Correlation Risk Analyst', category: 'Risk', description: 'Checks portfolio concentration and correlated exposure.' },
  { name: 'Tail Risk Analyst', category: 'Risk', description: 'Screens for tail-risk conditions such as gap and event risk.' },
  { name: 'Invalidation Analyst', category: 'Risk', description: 'Defines and monitors the specific condition that invalidates a thesis.' },

  // ---- Master (2) ----
  { name: 'Bull/Bear Debate Moderator', category: 'Master', description: 'Runs structured debate between bullish and bearish research groups.' },
  { name: 'Master CIO', category: 'Master', description: 'Synthesizes weighted consensus into a final reviewed signal decision.' },
]

function slugify(name: string): string {
  return name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '')
}

const CATEGORY_DEFAULT_WEIGHT: Record<AgentCategory, number> = {
  Technical: 0.7, Options: 0.7, Quant: 0.65, Fundamental: 0.5,
  Macro: 0.55, Intelligence: 0.5, Risk: 0.8, Master: 1.0,
}

export const AGENT_REGISTRY: AgentDefinition[] = SEEDS.map((seed, i) => ({
  id: `agent-${String(i + 1).padStart(3, '0')}-${slugify(seed.name)}`,
  name: seed.name,
  category: seed.category,
  description: seed.description,
  status: 'ACTIVE',
  version: '1.0.0',
  weight: CATEGORY_DEFAULT_WEIGHT[seed.category],
  enabled: true,
  createdAt: new Date('2026-01-01T00:00:00Z').toISOString(),
}))

export const AGENT_CATEGORIES: AgentCategory[] = [
  'Technical', 'Options', 'Quant', 'Fundamental', 'Macro', 'Intelligence', 'Risk', 'Master',
]
