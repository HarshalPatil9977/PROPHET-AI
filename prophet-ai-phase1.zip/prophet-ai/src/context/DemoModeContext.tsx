import { createContext, useContext, type ReactNode } from 'react'

export type AppMode = 'DEMO' | 'PAPER' | 'PRODUCTION'

// Phase 1 hard-locks the app to DEMO. Production mode must never be
// reachable until real, licensed providers are actually configured.
const CURRENT_MODE: AppMode = 'DEMO'

const DemoModeContext = createContext<AppMode>(CURRENT_MODE)

export function DemoModeProvider({ children }: { children: ReactNode }) {
  return <DemoModeContext.Provider value={CURRENT_MODE}>{children}</DemoModeContext.Provider>
}

export function useAppMode() {
  return useContext(DemoModeContext)
}
