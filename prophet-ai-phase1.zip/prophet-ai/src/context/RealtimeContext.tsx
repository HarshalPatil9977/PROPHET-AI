// ============================================================
// CENTRALIZED REAL-TIME MARKET UPDATE SERVICE
// ------------------------------------------------------------
// A single interval drives simulated quote updates for the whole app.
// Components subscribe to this context instead of running their own
// polling timers, matching the Provider -> Event Bus -> Services ->
// Frontend subscriptions architecture from the Phase 1 spec. Swap the
// interval-based tick for a real WebSocket message handler in production
// without changing any consumer.
// ============================================================

import { createContext, useContext, useEffect, useRef, useState, type ReactNode } from 'react'

interface RealtimeContextValue {
  tick: number
  lastUpdated: Date
  secondsAgo: number
}

const RealtimeContext = createContext<RealtimeContextValue>({ tick: 0, lastUpdated: new Date(), secondsAgo: 0 })

const UPDATE_INTERVAL_MS = 4000

export function RealtimeProvider({ children }: { children: ReactNode }) {
  const [tick, setTick] = useState(0)
  const [lastUpdated, setLastUpdated] = useState(new Date())
  const [secondsAgo, setSecondsAgo] = useState(0)
  const tickRef = useRef(0)

  useEffect(() => {
    const updateInterval = setInterval(() => {
      tickRef.current += 1
      setTick(tickRef.current)
      setLastUpdated(new Date())
    }, UPDATE_INTERVAL_MS)

    const clockInterval = setInterval(() => {
      setSecondsAgo(prev => prev + 1)
    }, 1000)

    return () => { clearInterval(updateInterval); clearInterval(clockInterval) }
  }, [])

  useEffect(() => { setSecondsAgo(0) }, [tick])

  return (
    <RealtimeContext.Provider value={{ tick, lastUpdated, secondsAgo }}>
      {children}
    </RealtimeContext.Provider>
  )
}

export function useRealtime() {
  return useContext(RealtimeContext)
}
