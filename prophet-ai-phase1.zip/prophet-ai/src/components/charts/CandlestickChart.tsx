import { useMemo } from 'react'
import type { Candle } from '@/types'

// Lightweight hand-rolled SVG candlestick + volume chart. Kept dependency-free
// (no external charting lib needed) so it stays fast for a scanner-density UI.
export default function CandlestickChart({ candles, height = 320 }: { candles: Candle[]; height?: number }) {
  const { bars, minPrice, maxPrice, maxVol, width } = useMemo(() => {
    const min = Math.min(...candles.map(c => c.low))
    const max = Math.max(...candles.map(c => c.high))
    const maxVolume = Math.max(...candles.map(c => c.volume))
    return { bars: candles, minPrice: min, maxPrice: max, maxVol: maxVolume, width: Math.max(600, candles.length * 8) }
  }, [candles])

  if (bars.length === 0) return null

  const priceHeight = height * 0.75
  const volHeight = height * 0.2
  const padding = (maxPrice - minPrice) * 0.08 || 1
  const yScale = (p: number) => priceHeight - ((p - (minPrice - padding)) / ((maxPrice + padding) - (minPrice - padding))) * priceHeight
  const barWidth = Math.max(3, (width / bars.length) * 0.6)

  return (
    <div className="overflow-x-auto">
      <svg width={width} height={height} className="block">
        {bars.map((c, i) => {
          const x = (i * width) / bars.length + (width / bars.length - barWidth) / 2
          const isUp = c.close >= c.open
          const color = isUp ? '#3fb98a' : '#d9584f'
          const bodyTop = yScale(Math.max(c.open, c.close))
          const bodyBottom = yScale(Math.min(c.open, c.close))
          const volH = (c.volume / maxVol) * volHeight
          return (
            <g key={c.time}>
              <line x1={x + barWidth / 2} x2={x + barWidth / 2} y1={yScale(c.high)} y2={yScale(c.low)} stroke={color} strokeWidth={1} />
              <rect x={x} y={bodyTop} width={barWidth} height={Math.max(1, bodyBottom - bodyTop)} fill={color} />
              <rect x={x} y={priceHeight + 20 + (volHeight - volH)} width={barWidth} height={volH} fill={color} opacity={0.5} />
            </g>
          )
        })}
        <line x1={0} x2={width} y1={priceHeight + 10} y2={priceHeight + 10} stroke="#232a38" strokeWidth={1} />
      </svg>
    </div>
  )
}
