import { Navigate } from 'react-router-dom'
import type { ReactNode } from 'react'
import { useAuth } from '@/context/AuthContext'
import type { UserRole } from '@/types'

export default function ProtectedRoute({ children, requiredRole }: { children: ReactNode; requiredRole?: UserRole }) {
  const { user, loading } = useAuth()

  if (loading) return <div className="flex h-screen items-center justify-center bg-base-950 text-ink-500 text-sm">Loading…</div>
  if (!user) return <Navigate to="/login" replace />
  if (requiredRole === 'admin' && user.role !== 'admin') {
    return (
      <div className="flex h-[70vh] flex-col items-center justify-center gap-2 text-center">
        <p className="text-sm font-medium text-signal-bear">Admin access required</p>
        <p className="text-2xs text-ink-500">Your role ({user.role}) does not have permission to view this page.</p>
      </div>
    )
  }
  return <>{children}</>
}
