import clsx from 'clsx'

type Tone = 'bull' | 'bear' | 'neutral' | 'info' | 'amber'

const TONE_CLASSES: Record<Tone, string> = {
  bull: 'text-signal-bull border-signal-bull/40 bg-signal-bull/10',
  bear: 'text-signal-bear border-signal-bear/40 bg-signal-bear/10',
  neutral: 'text-ink-300 border-base-600 bg-base-800',
  info: 'text-signal-info border-signal-info/40 bg-signal-info/10',
  amber: 'text-signal-amber border-signal-amber/40 bg-signal-amber/10',
}

export default function StatusPill({ label, tone }: { label: string; tone: Tone }) {
  return (
    <span className={clsx('inline-flex items-center border px-1.5 py-0.5 text-2xs font-medium mono', TONE_CLASSES[tone])}>
      {label}
    </span>
  )
}
