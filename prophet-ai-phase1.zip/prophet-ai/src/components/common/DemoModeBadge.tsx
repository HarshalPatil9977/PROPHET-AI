export default function DemoModeBadge() {
  return (
    <div
      className="group relative flex items-center gap-1.5 border border-signal-amber/40 bg-signal-amber/10 px-2 py-1 text-2xs font-medium text-signal-amber mono"
      title="Market prices, signals and AI outputs are simulated for development."
    >
      <span className="h-1.5 w-1.5 rounded-full bg-signal-amber animate-pulse" />
      DEMO MODE
      <div className="pointer-events-none absolute right-0 top-full z-50 mt-2 w-64 border border-base-600 bg-base-850 p-2 text-2xs text-ink-300 opacity-0 shadow-lg transition-opacity group-hover:opacity-100">
        Market prices, signals and AI outputs are simulated for development. No live broker or exchange feed is connected.
      </div>
    </div>
  )
}
