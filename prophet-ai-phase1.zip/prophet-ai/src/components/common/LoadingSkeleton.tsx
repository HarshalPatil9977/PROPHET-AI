import clsx from 'clsx'

export default function LoadingSkeleton({ className }: { className?: string }) {
  return <div className={clsx('animate-pulse bg-base-800', className)} />
}

export function CardSkeleton() {
  return (
    <div className="border border-base-700 bg-base-900 p-4 space-y-3">
      <LoadingSkeleton className="h-3 w-24" />
      <LoadingSkeleton className="h-6 w-32" />
      <LoadingSkeleton className="h-3 w-full" />
    </div>
  )
}

export function TableSkeleton({ rows = 6 }: { rows?: number }) {
  return (
    <div className="space-y-1.5">
      {Array.from({ length: rows }).map((_, i) => (
        <LoadingSkeleton key={i} className="h-8 w-full" />
      ))}
    </div>
  )
}
