import type { ReactNode } from 'react'

// Standard empty/error/stale/disconnected treatments so no view ever
// silently presents stale data as live.

export function EmptyState({ title, description }: { title: string; description?: string }) {
  return (
    <div className="flex flex-col items-center justify-center gap-1 border border-dashed border-base-700 py-10 text-center">
      <p className="text-sm font-medium text-ink-100">{title}</p>
      {description && <p className="max-w-xs text-2xs text-ink-500">{description}</p>}
    </div>
  )
}

export function ErrorState({ title = 'Something went wrong', description, onRetry }: { title?: string; description?: string; onRetry?: () => void }) {
  return (
    <div className="flex flex-col items-center justify-center gap-2 border border-signal-bear/30 bg-signal-bear/5 py-10 text-center">
      <p className="text-sm font-medium text-signal-bear">{title}</p>
      {description && <p className="max-w-xs text-2xs text-ink-500">{description}</p>}
      {onRetry && (
        <button onClick={onRetry} className="focus-ring mt-1 border border-base-600 px-3 py-1 text-2xs text-ink-100 hover:bg-base-800">
          Retry
        </button>
      )}
    </div>
  )
}

export function StaleDataBanner({ lastSuccessfulUpdate }: { lastSuccessfulUpdate: Date }) {
  return (
    <div className="flex items-center gap-2 border border-signal-amber/40 bg-signal-amber/10 px-3 py-2 text-2xs text-signal-amber mono">
      <span>DATA CONNECTION LOST</span>
      <span className="text-ink-500">Last successful update: {lastSuccessfulUpdate.toLocaleTimeString()}</span>
    </div>
  )
}

export function Panel({ title, action, children }: { title: string; action?: ReactNode; children: ReactNode }) {
  return (
    <section className="border border-base-700 bg-base-900">
      <header className="flex items-center justify-between border-b border-base-700 px-4 py-2.5">
        <h2 className="text-2xs font-semibold uppercase tracking-wide text-ink-500">{title}</h2>
        {action}
      </header>
      <div className="p-4">{children}</div>
    </section>
  )
}
