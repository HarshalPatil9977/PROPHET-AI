import { useEffect, useState } from 'react'
import type { Quote } from '@/types'
import { marketDataService } from '@/services/marketData'
import { generateCandles } from '@/data/mock/priceEngine'
import Sparkline from '@/components/charts/Sparkline'
import { useRealtime } from '@/context/RealtimeContext'
import { CardSkeleton } from '@/components/common/LoadingSkeleton'

export default function IndexCard({ symbol, label }: { symbol: string; label: string }) {
  const [quote, setQuote] = useState<Quote | null>(null)
  const [spark, setSpark] = useState<number[]>([])
  const { tick } = useRealtime()

  useEffect(() => {
    let active = true
    marketDataService.getQuote(symbol).then(q => { if (active) setQuote(q) })
    const candles = generateCandles(symbol, '5m', 30)
    setSpark(candles.map(c => c.close))
    return () => { active = false }
  }, [symbol, tick])

  if (!quote) return <CardSkeleton />

  const positive = quote.change >= 0
  return (
    <div className="border border-base-700 bg-base-900 p-3">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-2xs uppercase tracking-wide text-ink-500">{label}</p>
          <p className="mt-0.5 text-lg font-semibold text-ink-100 mono">{quote.ltp.toLocaleString('en-IN', { maximumFractionDigits: 2 })}</p>
        </div>
        <span className={`text-2xs mono ${quote.marketStatus === 'OPEN' ? 'text-signal-bull' : 'text-ink-500'}`}>
          {quote.marketStatus}
        </span>
      </div>
      <div className="mt-1 flex items-center gap-2 text-2xs mono">
        <span className={positive ? 'text-signal-bull' : 'text-signal-bear'}>
          {positive ? '+' : ''}{quote.change.toFixed(2)} ({positive ? '+' : ''}{quote.changePercent.toFixed(2)}%)
        </span>
      </div>
      <div className="mt-2">
        <Sparkline data={spark} positive={positive} />
      </div>
    </div>
  )
}
