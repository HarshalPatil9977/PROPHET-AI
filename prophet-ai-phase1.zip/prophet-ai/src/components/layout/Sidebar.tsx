import { NavLink } from 'react-router-dom'
import { useState } from 'react'
import clsx from 'clsx'
import { useAuth } from '@/context/AuthContext'

interface NavItem { to: string; label: string; phase1: boolean }

const NAV_SECTIONS: { title: string; items: NavItem[] }[] = [
  {
    title: 'Overview', items: [
      { to: '/dashboard', label: 'Dashboard', phase1: true },
      { to: '/markets', label: 'Markets', phase1: true },
      { to: '/scanner', label: 'Scanner', phase1: true },
      { to: '/watchlists', label: 'Watchlists', phase1: true },
    ]
  },
  {
    title: 'Research', items: [
      { to: '/signals', label: 'Signals', phase1: true },
      { to: '/research', label: 'Research', phase1: false },
      { to: '/technical', label: 'Technical', phase1: false },
      { to: '/fundamentals', label: 'Fundamentals', phase1: false },
      { to: '/news', label: 'News', phase1: false },
      { to: '/options', label: 'Options', phase1: false },
      { to: '/regime', label: 'Regime', phase1: false },
    ]
  },
  {
    title: 'AI System', items: [
      { to: '/agents', label: 'Agents', phase1: true },
      { to: '/ai-chat', label: 'AI Chat', phase1: false },
      { to: '/strategies', label: 'Strategies', phase1: false },
    ]
  },
  {
    title: 'Execution', items: [
      { to: '/backtesting', label: 'Backtesting', phase1: false },
      { to: '/paper-trading', label: 'Paper Trading', phase1: false },
      { to: '/portfolio', label: 'Portfolio', phase1: false },
      { to: '/performance', label: 'Performance', phase1: false },
    ]
  },
  {
    title: 'System', items: [
      { to: '/alerts', label: 'Alerts', phase1: false },
      { to: '/reports', label: 'Reports', phase1: false },
      { to: '/admin', label: 'Admin', phase1: true },
    ]
  },
]

export default function Sidebar() {
  const [collapsed, setCollapsed] = useState(false)
  const { user } = useAuth()
  const visibleSections = NAV_SECTIONS.map(s => ({
    ...s,
    items: s.items.filter(i => i.to !== '/admin' || user?.role === 'admin'),
  }))

  return (
    <aside className={clsx('flex h-screen flex-col border-r border-base-700 bg-base-900 transition-all', collapsed ? 'w-14' : 'w-56')}>
      <div className="flex h-14 items-center justify-between border-b border-base-700 px-3">
        {!collapsed && (
          <div>
            <p className="text-sm font-bold tracking-tight text-ink-100">PROPHET AI</p>
            <p className="text-2xs text-ink-500 mono">Market Intelligence</p>
          </div>
        )}
        <button
          onClick={() => setCollapsed(c => !c)}
          className="focus-ring text-ink-500 hover:text-ink-100"
          aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          {collapsed ? '»' : '«'}
        </button>
      </div>

      <nav className="flex-1 overflow-y-auto py-2">
        {visibleSections.map(section => (
          <div key={section.title} className="mb-3">
            {!collapsed && <p className="px-3 py-1 text-2xs font-semibold uppercase tracking-wide text-ink-500">{section.title}</p>}
            {section.items.map(item => (
              <NavLink
                key={item.to}
                to={item.to}
                className={({ isActive }) => clsx(
                  'flex items-center justify-between px-3 py-1.5 text-sm transition-colors focus-ring',
                  isActive ? 'border-l-2 border-accent bg-accent/10 text-ink-100' : 'border-l-2 border-transparent text-ink-300 hover:bg-base-800 hover:text-ink-100'
                )}
              >
                {!collapsed && <span>{item.label}</span>}
                {!collapsed && !item.phase1 && <span className="text-2xs text-ink-500 mono">P2</span>}
                {collapsed && <span className="mono text-2xs">{item.label.slice(0, 2)}</span>}
              </NavLink>
            ))}
          </div>
        ))}
      </nav>
    </aside>
  )
}
