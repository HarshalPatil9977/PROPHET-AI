import { useRealtime } from '@/context/RealtimeContext'
import { useAuth } from '@/context/AuthContext'
import DemoModeBadge from '@/components/common/DemoModeBadge'

export default function Topbar() {
  const { secondsAgo } = useRealtime()
  const { user, logout } = useAuth()

  return (
    <header className="flex h-14 items-center justify-between border-b border-base-700 bg-base-900 px-4">
      <div className="flex items-center gap-3 text-2xs text-ink-500 mono">
        <span className="flex items-center gap-1.5">
          <span className="h-1.5 w-1.5 rounded-full bg-signal-bull animate-pulse" />
          LIVE SIMULATION
        </span>
        <span className="text-base-600">|</span>
        <span>Last updated: {secondsAgo}s ago</span>
      </div>

      <div className="flex items-center gap-3">
        <DemoModeBadge />
        {user && (
          <div className="flex items-center gap-2 border-l border-base-700 pl-3">
            <div className="text-right">
              <p className="text-2xs text-ink-100">{user.name}</p>
              <p className="text-2xs text-ink-500 mono uppercase">{user.role}</p>
            </div>
            <button onClick={logout} className="focus-ring border border-base-600 px-2 py-1 text-2xs text-ink-300 hover:bg-base-800">
              Log out
            </button>
          </div>
        )}
      </div>
    </header>
  )
}
