// ============================================================
// AGENT TYPES
// ============================================================

export type AgentCategory =
  | 'Technical' | 'Options' | 'Quant' | 'Fundamental'
  | 'Macro' | 'Intelligence' | 'Risk' | 'Master'

export type AgentStatus = 'ACTIVE' | 'IDLE' | 'DISABLED' | 'ERROR'

export interface AgentDefinition {
  id: string
  name: string
  category: AgentCategory
  description: string
  status: AgentStatus
  version: string
  weight: number
  enabled: boolean
  createdAt: string
}

export type Opinion = 'BULLISH' | 'BEARISH' | 'NEUTRAL'

// Structured, validated agent output. Agents never emit final trading
// signals directly -- only independent research opinions like this one.
export interface AgentOutput {
  id: string
  symbol: string
  agentId: string
  timestamp: number
  opinion: Opinion
  score: number
  confidence: number
  bullishFactors: string[]
  bearishFactors: string[]
  evidence: string[]
  risks: string[]
  timeframe: string
  invalidationCondition: string
  simulated: true
}

export type AgentRunStatus = 'RUNNING' | 'COMPLETED' | 'FAILED'

export interface AgentRun {
  id: string
  agentId: string
  runStarted: number
  runCompleted: number | null
  durationMs: number | null
  status: AgentRunStatus
  error: string | null
  outputId: string | null
}

export interface AgentPerformance {
  agentId: string
  totalRuns: number
  accuracy: number | null
  avgConfidence: number
  lastRunAt: number | null
}

export function validateAgentOutput(output: Partial<AgentOutput>): string[] {
  const errors: string[] = []
  if (!output.symbol) errors.push('symbol is required')
  if (!output.agentId) errors.push('agentId is required')
  if (output.score === undefined || output.score < -100 || output.score > 100) {
    errors.push('score must be between -100 and 100')
  }
  if (output.confidence === undefined || output.confidence < 0 || output.confidence > 100) {
    errors.push('confidence must be between 0 and 100')
  }
  if (!output.opinion) errors.push('opinion is required')
  if (!output.invalidationCondition) errors.push('invalidationCondition is required')
  if (!output.evidence || output.evidence.length === 0) errors.push('evidence must be non-empty')
  return errors
}
