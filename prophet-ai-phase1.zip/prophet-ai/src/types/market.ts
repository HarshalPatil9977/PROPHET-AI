// ============================================================
// MARKET DATA TYPES
// ============================================================

export type Exchange = 'NSE' | 'BSE'
export type InstrumentType = 'INDEX' | 'EQUITY' | 'DERIVATIVE'

export interface Instrument {
  symbol: string
  name: string
  exchange: Exchange
  type: InstrumentType
  sector: string
  isin?: string
}

export interface Quote {
  symbol: string
  ltp: number
  change: number
  changePercent: number
  open: number
  high: number
  low: number
  prevClose: number
  volume: number
  timestamp: number
  marketStatus: 'PRE_OPEN' | 'OPEN' | 'CLOSED'
}

export type Timeframe = '1m' | '5m' | '15m' | '30m' | '1h' | '4h' | '1D' | '1W'

export interface Candle {
  time: number
  open: number
  high: number
  low: number
  close: number
  volume: number
}

export interface MarketDepthLevel {
  price: number
  quantity: number
  orders: number
}

export interface MarketDepth {
  symbol: string
  bids: MarketDepthLevel[]
  asks: MarketDepthLevel[]
  timestamp: number
}

export interface SectorPerformance {
  sector: string
  changePercent: number
  advancers: number
  decliners: number
}

export interface MarketBreadth {
  advancers: number
  decliners: number
  unchanged: number
  advanceDeclineRatio: number
}

export interface MarketOverview {
  indices: Quote[]
  breadth: MarketBreadth
  sectorPerformance: SectorPerformance[]
  timestamp: number
}

export interface MarketDataProvider {
  getQuote(symbol: string): Promise<Quote>
  getQuotes(symbols: string[]): Promise<Quote[]>
  getHistoricalData(symbol: string, timeframe: Timeframe, bars: number): Promise<Candle[]>
  getMarketOverview(): Promise<MarketOverview>
  getSectorPerformance(): Promise<SectorPerformance[]>
  getMarketBreadth(): Promise<MarketBreadth>
  getInstrumentUniverse(): Promise<Instrument[]>
  getMarketDepth(symbol: string): Promise<MarketDepth>
}

export interface QuoteUpdateEvent { type: 'QUOTE_UPDATE'; payload: Quote }
export interface SignalUpdateEvent { type: 'SIGNAL_UPDATE'; payload: { signalId: string; status: string } }
export interface AgentUpdateEvent { type: 'AGENT_UPDATE'; payload: { agentId: string; status: string } }
export type MarketEvent = QuoteUpdateEvent | SignalUpdateEvent | AgentUpdateEvent
