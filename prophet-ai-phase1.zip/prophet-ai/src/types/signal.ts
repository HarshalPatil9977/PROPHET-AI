// ============================================================
// SIGNAL TYPES
// ============================================================

export type SignalDirection = 'BULLISH' | 'BEARISH'

export type SignalStatus =
  | 'WATCH' | 'DEVELOPING' | 'CONFIRMATION_PENDING' | 'CONFIRMED'
  | 'ACTIVE' | 'TARGET_HIT' | 'STOP_HIT' | 'EXPIRED' | 'INVALIDATED'

export interface Signal {
  id: string
  symbol: string
  direction: SignalDirection
  signalScore: number
  modelConfidence: number
  entryZoneLow: number
  entryZoneHigh: number
  stopLoss: number
  target1: number
  target2: number
  riskReward: number
  timeframe: string
  status: SignalStatus
  generatedAt: number
  bullishFactors: string[]
  bearishFactors: string[]
  evidence: string[]
  risk: string
  invalidationCondition: string
  simulated: true
}

export interface SignalOutcome {
  signalId: string
  outcome: 'TARGET_HIT' | 'STOP_HIT' | 'EXPIRED' | 'INVALIDATED' | 'PENDING'
  exitPrice: number | null
  pnlPercent: number | null
  closedAt: number | null
}

export function validateSignal(signal: Partial<Signal>): string[] {
  const errors: string[] = []
  if (!signal.symbol) errors.push('symbol is required')
  if (!signal.direction) errors.push('direction is required')
  if (!signal.invalidationCondition) errors.push('invalidationCondition is required')
  if (!signal.evidence || signal.evidence.length === 0) errors.push('evidence must be non-empty')
  if (signal.stopLoss !== undefined && signal.entryZoneLow !== undefined) {
    if (signal.direction === 'BULLISH' && signal.stopLoss >= signal.entryZoneLow) {
      errors.push('stopLoss must be below entry zone for a bullish signal')
    }
    if (signal.direction === 'BEARISH' && signal.entryZoneHigh !== undefined && signal.stopLoss <= signal.entryZoneHigh) {
      errors.push('stopLoss must be above entry zone for a bearish signal')
    }
  }
  return errors
}
