export type UserRole = 'user' | 'analyst' | 'admin'

export interface AuthUser {
  id: string
  email: string
  name: string
  role: UserRole
}
