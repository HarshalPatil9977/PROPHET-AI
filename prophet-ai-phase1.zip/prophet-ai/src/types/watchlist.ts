export interface WatchlistItem {
  id: string
  watchlistId: string
  symbol: string
  addedAt: string
}

export interface Watchlist {
  id: string
  userId: string
  name: string
  createdAt: string
  updatedAt: string
  items: WatchlistItem[]
}
