-- ============================================================
-- PROPHET AI -- PostgreSQL Schema (Phase 1 Foundation)
-- ------------------------------------------------------------
-- Not connected in Phase 1 (the app runs on demo/localStorage data).
-- This schema is the target shape for Phase 2+ when a real backend
-- is wired up. Time-series tables are annotated for future
-- TimescaleDB hypertable conversion.
-- ============================================================

create extension if not exists "uuid-ossp";

-- ---------------- USERS & PROFILES ----------------
create table users (
  id uuid primary key default uuid_generate_v4(),
  email text unique not null,
  role text not null default 'user' check (role in ('user','analyst','admin')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table profiles (
  user_id uuid primary key references users(id) on delete cascade,
  display_name text,
  avatar_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ---------------- INSTRUMENTS ----------------
create table exchanges (
  code text primary key,
  name text not null
);

create table sectors (
  id uuid primary key default uuid_generate_v4(),
  name text unique not null
);

create table instruments (
  symbol text primary key,
  name text not null,
  exchange_code text not null references exchanges(code),
  instrument_type text not null check (instrument_type in ('INDEX','EQUITY','DERIVATIVE')),
  sector_id uuid references sectors(id),
  isin text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ---------------- MARKET DATA (time-series candidates) ----------------
create table market_quotes (
  id uuid primary key default uuid_generate_v4(),
  symbol text not null references instruments(symbol),
  ltp numeric(14,4) not null,
  change numeric(14,4) not null,
  change_percent numeric(8,4) not null,
  open numeric(14,4), high numeric(14,4), low numeric(14,4), prev_close numeric(14,4),
  volume bigint,
  market_status text not null,
  ts timestamptz not null default now()
);
create index idx_market_quotes_symbol on market_quotes(symbol);
create index idx_market_quotes_ts on market_quotes(ts);

create table historical_prices (
  id uuid primary key default uuid_generate_v4(),
  symbol text not null references instruments(symbol),
  timeframe text not null,
  open numeric(14,4), high numeric(14,4), low numeric(14,4), close numeric(14,4),
  volume bigint,
  ts timestamptz not null
);
create index idx_historical_prices_symbol on historical_prices(symbol);
create index idx_historical_prices_ts on historical_prices(ts);
-- Future: select create_hypertable('historical_prices', 'ts');

create table market_depth (
  id uuid primary key default uuid_generate_v4(),
  symbol text not null references instruments(symbol),
  bids jsonb not null,
  asks jsonb not null,
  ts timestamptz not null default now()
);
create index idx_market_depth_symbol on market_depth(symbol);

-- ---------------- WATCHLISTS ----------------
create table watchlists (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references users(id) on delete cascade,
  name text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index idx_watchlists_user_id on watchlists(user_id);

create table watchlist_items (
  id uuid primary key default uuid_generate_v4(),
  watchlist_id uuid not null references watchlists(id) on delete cascade,
  symbol text not null references instruments(symbol),
  added_at timestamptz not null default now()
);
create index idx_watchlist_items_watchlist_id on watchlist_items(watchlist_id);

-- ---------------- AI AGENTS ----------------
create table ai_agents (
  id text primary key,
  name text not null,
  category text not null check (category in
    ('Technical','Options','Quant','Fundamental','Macro','Intelligence','Risk','Master')),
  description text not null,
  status text not null default 'ACTIVE' check (status in ('ACTIVE','IDLE','DISABLED','ERROR')),
  version text not null default '1.0.0',
  weight numeric(4,3) not null default 0.5,
  enabled boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table agent_runs (
  id uuid primary key default uuid_generate_v4(),
  agent_id text not null references ai_agents(id),
  run_started timestamptz not null default now(),
  run_completed timestamptz,
  duration_ms integer,
  status text not null check (status in ('RUNNING','COMPLETED','FAILED')),
  error text,
  output_id uuid
);
create index idx_agent_runs_agent_id on agent_runs(agent_id);

create table agent_outputs (
  id uuid primary key default uuid_generate_v4(),
  symbol text not null references instruments(symbol),
  agent_id text not null references ai_agents(id),
  opinion text not null check (opinion in ('BULLISH','BEARISH','NEUTRAL')),
  score numeric(6,2) not null check (score between -100 and 100),
  confidence numeric(6,2) not null check (confidence between 0 and 100),
  bullish_factors jsonb not null default '[]',
  bearish_factors jsonb not null default '[]',
  risks jsonb not null default '[]',
  timeframe text,
  invalidation_condition text not null,
  simulated boolean not null default true,
  ts timestamptz not null default now()
);
create index idx_agent_outputs_symbol on agent_outputs(symbol);
create index idx_agent_outputs_agent_id on agent_outputs(agent_id);

create table agent_evidence (
  id uuid primary key default uuid_generate_v4(),
  agent_output_id uuid not null references agent_outputs(id) on delete cascade,
  statement text not null
);

create table agent_performance (
  agent_id text primary key references ai_agents(id),
  total_runs integer not null default 0,
  accuracy numeric(6,3),
  avg_confidence numeric(6,2),
  last_run_at timestamptz,
  updated_at timestamptz not null default now()
);

-- ---------------- MARKET REGIME ----------------
create table market_regimes (
  id uuid primary key default uuid_generate_v4(),
  regime text not null,
  volatility_bucket text not null,
  classified_at timestamptz not null default now()
);

-- ---------------- SIGNALS ----------------
create table signals (
  id uuid primary key default uuid_generate_v4(),
  symbol text not null references instruments(symbol),
  direction text not null check (direction in ('BULLISH','BEARISH')),
  signal_score numeric(6,2) not null,
  model_confidence numeric(6,2) not null,
  entry_zone_low numeric(14,4) not null,
  entry_zone_high numeric(14,4) not null,
  stop_loss numeric(14,4) not null,
  target_1 numeric(14,4) not null,
  target_2 numeric(14,4) not null,
  risk_reward numeric(6,2) not null,
  timeframe text not null,
  status text not null check (status in
    ('WATCH','DEVELOPING','CONFIRMATION_PENDING','CONFIRMED','ACTIVE','TARGET_HIT','STOP_HIT','EXPIRED','INVALIDATED')),
  risk text,
  invalidation_condition text not null,
  simulated boolean not null default true,
  generated_at timestamptz not null default now()
);
create index idx_signals_symbol on signals(symbol);
create index idx_signals_status on signals(status);

create table signal_evidence (
  id uuid primary key default uuid_generate_v4(),
  signal_id uuid not null references signals(id) on delete cascade,
  statement text not null,
  polarity text check (polarity in ('BULLISH','BEARISH','NEUTRAL'))
);
create index idx_signal_evidence_signal_id on signal_evidence(signal_id);

create table signal_lifecycle (
  id uuid primary key default uuid_generate_v4(),
  signal_id uuid not null references signals(id) on delete cascade,
  status text not null,
  changed_at timestamptz not null default now()
);
create index idx_signal_lifecycle_signal_id on signal_lifecycle(signal_id);

create table signal_outcomes (
  signal_id uuid primary key references signals(id) on delete cascade,
  outcome text not null check (outcome in ('TARGET_HIT','STOP_HIT','EXPIRED','INVALIDATED','PENDING')),
  exit_price numeric(14,4),
  pnl_percent numeric(8,4),
  closed_at timestamptz
);

-- ---------------- ALERTS / SYSTEM ----------------
create table alerts (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references users(id) on delete cascade,
  symbol text references instruments(symbol),
  condition text not null,
  triggered boolean not null default false,
  created_at timestamptz not null default now()
);
create index idx_alerts_user_id on alerts(user_id);

create table system_logs (
  id uuid primary key default uuid_generate_v4(),
  category text not null check (category in ('LOGIN','ADMIN_ACTION','SIGNAL_CREATION','CONFIG_CHANGE','ERROR')),
  actor_user_id uuid references users(id),
  message text not null,
  metadata jsonb default '{}',
  created_at timestamptz not null default now()
);
create index idx_system_logs_category on system_logs(category);

create table api_health (
  id uuid primary key default uuid_generate_v4(),
  service_name text not null,
  status text not null check (status in ('ONLINE','DEGRADED','OFFLINE')),
  checked_at timestamptz not null default now()
);
