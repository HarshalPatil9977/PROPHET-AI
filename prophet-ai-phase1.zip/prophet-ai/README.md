# PROPHET AI — Multi-Agent Market Intelligence Platform

**Phase 1: Foundation.** This is a demo-mode application. No live market data,
no real AI inference, no broker execution. Every screen that shows prices,
signals, or AI output is clearly labeled `DEMO DATA` / `SIMULATED`.

## What's implemented in Phase 1

- Application shell with collapsible sidebar navigation and a top bar showing
  live-simulation status and a persistent Demo Mode indicator
- Auth scaffold (login/logout, role-based routing: `user`, `analyst`, `admin`)
- Fully working: `/login`, `/dashboard`, `/markets`, `/signals`, `/scanner`,
  `/watchlists`, `/agents`, `/admin`
- Polished "Module coming in Phase 2" placeholders for every other route in
  the spec (`/research`, `/technical`, `/fundamentals`, `/news`, `/regime`,
  `/strategies`, `/backtesting`, `/paper-trading`, `/portfolio`, `/ai-chat`,
  `/reports`, `/performance`, `/alerts`, `/options`)
- `MarketDataProvider` interface + `MockMarketDataProvider` implementation
  with a deterministic, seeded price-walk engine (55-instrument demo universe)
- Full 60-agent registry across 8 categories (Technical, Options, Quant,
  Fundamental, Macro, Intelligence, Risk, Master)
- `DemoAgentProvider` producing structured, schema-validated `AgentOutput`s
  (agents never emit final signals directly — only opinions)
- A lightweight weighted-consensus scorer and demo signal generator that
  stand in for the full Debate Engine / Master CIO shipping in Phase 4
- Watchlist CRUD, persisted (demo-mode persistence, see Known Limitations)
- Centralized real-time update service (one interval, no per-component
  polling) driving simulated quote refreshes every 4 seconds
- PostgreSQL schema (`db/schema.sql`) for the full target data model
- Loading / empty / error / stale-data states used consistently
- Vitest suite covering agent-output validation, signal validation, the
  60-agent registry integrity, and price-engine determinism

## Getting started

```bash
npm install
npm run dev       # start the dev server
npm run build     # type-check + production build
npm run test      # run the vitest suite
```

Demo credentials (shown on the login screen):

| Email                 | Password   | Role    |
|-----------------------|------------|---------|
| demo@prophet.ai       | demo1234   | user    |
| analyst@prophet.ai    | analyst123 | analyst |
| admin@prophet.ai      | admin123   | admin   |

## Demo Mode

The app is hard-locked to `DEMO` mode in `src/context/DemoModeContext.tsx`.
The intended progression is:

```
DEMO → PAPER → PRODUCTION
```

`PRODUCTION` must never be reachable until a real, licensed market-data
provider and a real backend are actually wired in — this is enforced by
having exactly one place (`MockMarketDataProvider`) that would need to be
swapped, not scattered mock calls across the UI.

## Folder structure

```
src/
├── components/   UI components (layout, market, charts, common, ...)
├── pages/        Route-level pages
├── services/     Thin business-logic layer between UI and data/AI
├── ai/
│   ├── agents/       DemoAgentProvider (simulated structured output)
│   ├── scoring/      Weighted consensus aggregation
│   ├── master/       Demo signal generation (Master CIO placeholder)
│   ├── orchestrator/ Reserved for Phase 3 real agent execution
│   └── debate/        Reserved for Phase 4 Bull/Bear Debate Engine
├── data/
│   ├── mock/       Instrument universe, deterministic price engine, agent registry
│   └── providers/  MockMarketDataProvider (implements the MarketDataProvider interface)
├── context/      React contexts: auth, realtime updates, demo mode
├── types/        Shared TypeScript types + structured-output validators
├── hooks/ lib/ utils/  (scaffolded, ready for Phase 2+)
db/
└── schema.sql    Target PostgreSQL schema (not connected in Phase 1)
tests/
└── validation.test.ts
```

See `ARCHITECTURE.md` for the layering rules and how production data
providers plug in later.

## Environment variables

None are required to run Phase 1. `.env.example` documents the variables a
future production integration (licensed market data, Supabase auth, a real
Postgres instance) would need. No API keys or credentials are read or
embedded anywhere in this codebase.

## Database setup

Phase 1 does not connect to a database — watchlists and auth sessions are
persisted to `localStorage` as a placeholder. `db/schema.sql` defines the
full target schema (users, instruments, market data, watchlists, agents,
signals, alerts, logs) so the swap to a real Postgres instance in Phase 2
is a service-layer change, not a rewrite.

## API structure

Phase 1 does not run a separate backend server. `src/services/*` model the
same responsibilities the future REST API (`GET /api/market/overview`,
`GET /api/signals`, `GET /api/agents`, etc.) will expose, so UI components
already depend only on service function signatures — swapping an in-process
service call for a `fetch()` to a real endpoint won't touch any page or
component.

## Future production data provider integration

1. Implement a new class satisfying the `MarketDataProvider` interface
   (`src/types/market.ts`) against a licensed vendor.
2. Point `src/services/marketData/index.ts` at the new implementation.
3. Wire `db/schema.sql` into a real Postgres/TimescaleDB instance and swap
   `src/services/watchlists.ts` and `src/services/auth.ts` from
   `localStorage` to real API calls.
4. Nothing in `src/pages` or `src/components` needs to change.
