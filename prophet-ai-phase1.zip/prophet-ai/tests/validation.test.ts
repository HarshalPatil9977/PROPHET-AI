import { describe, it, expect } from 'vitest'
import { validateAgentOutput, validateSignal } from '@/types'
import { generateAgentOutput } from '@/ai/agents/DemoAgentProvider'
import { AGENT_REGISTRY } from '@/data/mock/agentRegistry'
import { mockMarketDataProvider } from '@/data/providers/MockMarketDataProvider'

describe('agent output validation', () => {
  it('rejects an output missing evidence', () => {
    const errors = validateAgentOutput({ symbol: 'TCS', agentId: 'a1', score: 10, confidence: 50, opinion: 'BULLISH', invalidationCondition: 'x', evidence: [] })
    expect(errors).toContain('evidence must be non-empty')
  })

  it('rejects a confidence value out of range', () => {
    const errors = validateAgentOutput({ symbol: 'TCS', agentId: 'a1', score: 10, confidence: 150, opinion: 'BULLISH', invalidationCondition: 'x', evidence: ['e'] })
    expect(errors.length).toBeGreaterThan(0)
  })

  it('every simulated agent output for every registered agent validates cleanly', () => {
    for (const agent of AGENT_REGISTRY.filter(a => a.category !== 'Master')) {
      const output = generateAgentOutput(agent, 'RELIANCE')
      expect(validateAgentOutput(output)).toEqual([])
    }
  })
})

describe('signal validation', () => {
  it('flags a bullish signal whose stop loss sits above the entry zone', () => {
    const errors = validateSignal({
      symbol: 'TCS', direction: 'BULLISH', entryZoneLow: 100, entryZoneHigh: 105,
      stopLoss: 110, invalidationCondition: 'x', evidence: ['e'],
    })
    expect(errors.some(e => e.includes('stopLoss'))).toBe(true)
  })
})

describe('agent registry', () => {
  it('registers exactly 60 agents', () => {
    expect(AGENT_REGISTRY.length).toBe(60)
  })

  it('has no duplicate agent ids', () => {
    const ids = new Set(AGENT_REGISTRY.map(a => a.id))
    expect(ids.size).toBe(AGENT_REGISTRY.length)
  })
})

describe('mock market data provider', () => {
  it('returns a deterministic quote within the same time bucket', async () => {
    const q1 = await mockMarketDataProvider.getQuote('RELIANCE')
    const q2 = await mockMarketDataProvider.getQuote('RELIANCE')
    expect(q1.ltp).toBe(q2.ltp)
  })

  it('generates historical candles with monotonically increasing time', async () => {
    const candles = await mockMarketDataProvider.getHistoricalData('NIFTY', '1D', 20)
    for (let i = 1; i < candles.length; i++) {
      expect(candles[i].time).toBeGreaterThan(candles[i - 1].time)
    }
  })
})
