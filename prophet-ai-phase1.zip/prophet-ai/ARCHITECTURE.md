# Architecture — PROPHET AI Phase 1

## Layering rule

```
UI  →  API (future)  →  SERVICES  →  DATA PROVIDERS  →  DATABASE
```

The AI layer is kept independent of the UI/data path:

```
AI AGENTS  →  AGENT ORCHESTRATOR  →  AGENT OUTPUTS  →  MASTER CIO
```

`src/pages` and `src/components` never import `src/data/providers` or
`src/ai/*` directly for market data — they always go through
`src/services/*`. This is what makes the mock→production provider swap a
one-line change instead of a rewrite.

## Data layer

- `src/types/market.ts` defines the `MarketDataProvider` interface every
  provider must satisfy: `getQuote`, `getQuotes`, `getHistoricalData`,
  `getMarketOverview`, `getSectorPerformance`, `getMarketBreadth`,
  `getInstrumentUniverse`, `getMarketDepth`.
- `src/data/mock/priceEngine.ts` is a **deterministic** seeded price-walk
  generator (Mulberry32 PRNG keyed on `symbol:timeframe:timeBucket`).
  Repeated calls within the same time bucket return identical candles, so
  charts don't jitter on every re-render — only the real update interval
  (`RealtimeContext`, 4s) advances the bucket.
- `src/data/providers/MockMarketDataProvider.ts` implements the interface
  on top of that engine. It is the **only** class a production integration
  needs to replace.
- `db/schema.sql` is the target Postgres schema. Time-series-heavy tables
  (`historical_prices`, `market_quotes`) are annotated for a future
  `create_hypertable(...)` TimescaleDB conversion.

## Agent layer

- `src/data/mock/agentRegistry.ts` defines all 60 agents (10 Technical,
  8 Options, 8 Quant, 8 Fundamental, 8 Macro, 10 Intelligence, 6 Risk,
  2 Master), each with an id, category, weight, and enabled flag.
- `src/types/agent.ts` defines `AgentOutput` — the only shape an agent is
  allowed to produce — plus `validateAgentOutput`, which every simulated
  (and, later, real) output is run through before it's allowed to persist.
  **Agents never emit a final trading signal directly**, only opinions
  with evidence, confidence, and an explicit invalidation condition.
- `src/ai/agents/DemoAgentProvider.ts` generates a structured, validated
  `AgentOutput` per agent per symbol per hour bucket (deterministic, loosely
  tied to the simulated price trend so opinions aren't pure noise). This is
  **simulated output**, not real inference — real agent execution is a
  Phase 3 concern and would replace this module's internals behind the same
  `generateAgentOutput` / `generateAllAgentOutputs` signatures.

## Signal layer

Phase 1 ships a lightweight stand-in for the full pipeline defined for
Phase 4:

```
Independent AgentOutputs
      ↓
computeConsensus()         (src/ai/scoring/consensus.ts — weighted by agent weight)
      ↓
generateSignalFromConsensus()  (src/ai/master/signalGenerator.ts)
      ↓
Signal  (validated via validateSignal(), src/types/signal.ts)
```

`src/ai/orchestrator` and `src/ai/debate` are scaffolded but intentionally
empty — they're reserved for the real Bull/Bear Debate Engine and Master
CIO described in the Phase 4 spec. Every `Signal` still carries evidence,
bullish/bearish factors, risk, and an invalidation condition today, so the
Signal Center UI contract won't change when the real debate engine lands.

## Real-time layer

A single `RealtimeProvider` (`src/context/RealtimeContext.tsx`) runs one
`setInterval` for the whole app and exposes `{ tick, lastUpdated,
secondsAgo }`. Components re-fetch on `tick` change instead of running
their own timers — this is the "Provider → Event Bus → Services →
WebSocket-ready layer → Frontend subscriptions" architecture from the spec,
implemented without a real WebSocket yet. Swapping the `setInterval` tick
for real WebSocket message handling later requires touching only this one
file.

## Database

See `db/schema.sql`. Phase 1 does not connect to it — `watchlists` and auth
sessions persist to `localStorage` behind the same service function
signatures (`src/services/watchlists.ts`, `src/services/auth.ts`) that a
real backend would expose, so swapping the implementation later is
contained to those two files.

## Real-time / demo mode guardrails

- `src/context/DemoModeContext.tsx` hard-codes the app to `DEMO` mode.
  There is no code path that can reach `PRODUCTION` without a developer
  explicitly wiring in a real provider and flipping this value.
- Every quote/signal/agent-output surface in the UI carries a "DEMO DATA",
  "SIMULATED AI CONSENSUS", or "SIMULATED AGENT OUTPUT" label so simulated
  output can never be mistaken for a live feed.

## Future production deployment

1. Real market data: implement `MarketDataProvider` against a licensed feed,
   point `src/services/marketData/index.ts` at it.
2. Real backend: stand up the Postgres schema in `db/schema.sql` (with
   TimescaleDB for the time-series tables), add a thin API layer matching
   the endpoints listed in the README, move `watchlists.ts`/`auth.ts` off
   `localStorage`.
3. Real AI: replace `DemoAgentProvider` with real per-agent inference calls
   that still produce the same validated `AgentOutput` shape; implement the
   real Bull/Bear Debate Engine and Master CIO (Phase 4) behind
   `src/ai/orchestrator` and `src/ai/debate`.
4. Flip `DemoModeContext` to `PAPER` once paper trading (Phase 6) is wired
   to the real signal pipeline, and only consider `PRODUCTION` after every
   provider above is real and licensed — this app must never execute
   real-money trades.
